<?php
// functions.php

function checkUserConditions($user)
{
    if ($_SESSION['user_email'] !== $user['email']) {
        session_unset();
        session_destroy();
        return [
            'redirect' => true,
            'url' => "sign-in?status=session_email_mismatch"
        ];
    }


    if ($user['email_verified'] == 0) {
        return [
            'redirect' => true,
            'url' => "verify-email?status=email_verification_required"
        ];
    }

    if ($user['profile_updated'] == 0) {
        return [
            'redirect' => true,
           
        ];
    }

    if ($user['user_type'] !== 'admin') {
        session_unset();
        session_destroy();
        return [
            'redirect' => true,
            'url' => "sign-in?status=access_denied"
        ];
    }

    // No conditions met, continue as normal
    return ['redirect' => false];
}
