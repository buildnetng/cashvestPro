<?php
session_start();
require_once __DIR__ . '../../vendor/mailer.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and validate inputs
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = filter_input(INPUT_POST, 'password', FILTER_DEFAULT);

    if (empty($email) || empty($password)) {
        echo json_encode(['status' => 'error', 'messages' => ['Email and password are required.']]);
        exit;
    }

    require 'config.php';

    // Prepare SQL statement to check the user's credentials
    $stmt = $mysqli->prepare("SELECT id, full_name, password, email_verified, verification_code, user_type FROM users WHERE email = ?");
    if ($stmt) {
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($userId, $fullName, $hashedPassword, $emailVerified, $existingVerificationCode, $userType);
        $stmt->fetch();

        if ($stmt->num_rows === 1) {
            // Verify the password
            if (password_verify($password, $hashedPassword)) {
                if ($emailVerified) {
                    // Check if the user is an admin
                    if ($userType !== 'admin') {
                        echo json_encode([
                            'status' => 'error',
                            'messages' => [
                                'Access granted, but you\'re not allowed to access this resource. Please contact the administrators.'
                            ]
                        ]);
                        exit;
                    }

                    // Store user information in session
                    $_SESSION['user_id'] = $userId;
                    $_SESSION['user_email'] = $email;

                    // Send a login notification email
                    $loginNotificationMessage = "
                        <p>Hello $fullName,</p>
                        <p>This is to notify you that your account was just accessed. If this wasn't you, please secure your account immediately.</p>
                        <p>Regards,<br>Your Company</p>
                    ";
                    if (!sendEmail($email, "Login Notification", $loginNotificationMessage)) {
                        echo json_encode(['status' => 'error', 'messages' => ['Failed to send login notification email.']]);
                        exit;
                    }

                    echo json_encode(['status' => 'success', 'messages' => ['Login successful!']]);
                    exit;
                } else {
                    // Handle unverified email case
                    $verificationCode = $existingVerificationCode ? $existingVerificationCode : bin2hex(random_bytes(16));

                    // Store the verification code in the database if it's new
                    if (!$existingVerificationCode) {
                        $stmtUpdate = $mysqli->prepare("UPDATE users SET verification_code = ? WHERE id = ?");
                        if ($stmtUpdate) {
                            $stmtUpdate->bind_param('si', $verificationCode, $userId);
                            $stmtUpdate->execute();
                            $stmtUpdate->close();
                        } else {
                            echo json_encode(['status' => 'error', 'messages' => ['Failed to generate verification code. Please try again.']]);
                            exit;
                        }
                    }

                    // Prepare and send the verification email
                    $verificationLink = "http://yourdomain.com/verify_email.php?code=$verificationCode&email=" . urlencode($email);
                    $verificationMessage = "
                        <p>Hello $fullName,</p>
                        <p>Please click the link below to verify your email address:</p>
                        <p><a href='$verificationLink'>Verify Email</a></p>
                        <p>Regards,<br>Your Company</p>
                    ";
                    if (!sendEmail($email, "Email Verification", $verificationMessage)) {
                        echo json_encode(['status' => 'error', 'messages' => ['Failed to send verification email.']]);
                        exit;
                    }

                    echo json_encode([
                        'status' => 'error',
                        'messages' => [
                            'Your email is not verified. A new verification link has been sent to your email. Please check your inbox to complete the verification process. Kindly hold on while you are being redirected.'
                        ]
                    ]);
                    exit;
                }
            } else {
                echo json_encode(['status' => 'error', 'messages' => ['Invalid password.']]);
                exit;
            }
        } else {
            echo json_encode(['status' => 'error', 'messages' => ['Invalid email or password.']]);
            exit;
        }

        $stmt->close();
    } else {
        echo json_encode(['status' => 'error', 'messages' => [$mysqli->error]]);
        exit;
    }
} else {
    echo json_encode(['status' => 'error', 'messages' => ['Invalid request method.']]);
    exit;
}

$mysqli->close();
