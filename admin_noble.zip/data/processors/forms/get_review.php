<?php
require_once '../config.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $id = intval($_GET['id']);
    $query = "SELECT `first_name`, `last_name`, `email`, `review_details`, `rating` FROM `user_reviews` WHERE `id` = $id";
    $result = $mysqli->query($query);
    if ($result->num_rows > 0) {
        $review = $result->fetch_assoc();
        echo json_encode(['status' => 'success', 'review' => $review]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Review not found.']);
    }
    $mysqli->close();
}



