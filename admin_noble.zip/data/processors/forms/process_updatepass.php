<?php
session_start();
header('Content-Type: application/json');

// Initialize response array
$response = ['status' => 'error', 'messages' => []];

// Check if all required POST parameters are set
if (isset($_POST['currentPassword']) && isset($_POST['newPassword']) && isset($_POST['confirmPassword'])) {
    $currentPassword = trim($_POST['currentPassword']);
    $newPassword = trim($_POST['newPassword']);
    $confirmPassword = trim($_POST['confirmPassword']);

    // Validate passwords
    if ($newPassword !== $confirmPassword) {
        $response['messages'][] = 'New passwords do not match.';
    } else {
        require "../config.php"; // Database configuration file

        // Prepare and execute query to get current user data
        $userId = $_SESSION['user_id'];
        $stmt = $mysqli->prepare('SELECT `password` FROM `users` WHERE `id` = ?');
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $stmt->bind_result($dbPassword);
        $stmt->fetch();
        $stmt->close();

        // Verify the current password
        if (password_verify($currentPassword, $dbPassword)) {
            // Hash the new password
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

            // Update the password in the database
            $stmt = $mysqli->prepare('UPDATE `users` SET `password` = ? WHERE `id` = ?');
            $stmt->bind_param('si', $hashedPassword, $userId);
            if ($stmt->execute()) {
                $response['status'] = 'success';
                $response['messages'][] = 'Password changed successfully!';
            } else {
                $response['messages'][] = 'Failed to update password.';
            }
            $stmt->close();
        } else {
            $response['messages'][] = 'Current password is incorrect.';
        }

        // Close the database connection
        $mysqli->close();
    }
} else {
    $response['messages'][] = 'All fields are required.';
}

// Output the response as JSON
echo json_encode($response);
