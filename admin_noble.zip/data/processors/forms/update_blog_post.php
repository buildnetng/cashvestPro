<?php
require_once '../config.php';
header('Content-Type: application/json');

// Function to generate a unique filename
function generateUniqueFilename($originalName)
{
    $ext = pathinfo($originalName, PATHINFO_EXTENSION);
    $uniqueName = uniqid('blog_', true) . '.' . $ext;
    return $uniqueName;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve POST data
    $id = intval($_POST['id']);
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $currentImage = trim($_POST['currentImage']);
    $image = $_FILES['image']['name'] ?? $currentImage;

    // Define upload directory
    $uploadDir = '../../../uploads/blog_post/';

    // Ensure the directory exists and create it if necessary
    if (!is_dir($uploadDir)) {
        if (!mkdir($uploadDir, 0777, true)) {
            echo json_encode(['status' => 'error', 'message' => 'Failed to create the blog_post directory.']);
            exit;
        }
    }

    // Handle file upload
    if (!empty($_FILES['image']['name'])) {
        $newImageName = generateUniqueFilename($_FILES['image']['name']);
        $uploadFile = $uploadDir . $newImageName;

        // Move uploaded file
        if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadFile)) {
            $image = 'uploads/blog_post/' . $newImageName; // Relative path

            // Optionally, delete old image if a new one was uploaded
            if ($currentImage && file_exists($uploadDir . str_replace('uploads/blog_post/', '', $currentImage)) && $currentImage !== $image) {
                unlink($uploadDir . str_replace('uploads/blog_post/', '', $currentImage));
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to upload the new image.']);
            exit;
        }
    } else {
        $image = $currentImage; // Keep the current image if no new file is uploaded
    }

    // Prepare and execute SQL update query
    $sql = "UPDATE blog_posts SET blog_title=?, description=?, image_path=? WHERE id=?";
    if ($stmt = $mysqli->prepare($sql)) {
        $stmt->bind_param('sssi', $title, $description, $image, $id);

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to update post: ' . $stmt->error]);
        }
        $stmt->close();
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to prepare SQL statement: ' . $mysqli->error]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}

$mysqli->close();
