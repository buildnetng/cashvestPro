<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require "../config.php";

    $first_name = htmlspecialchars(trim($_POST['first_name']), ENT_QUOTES, 'UTF-8');
    $last_name = htmlspecialchars(trim($_POST['last_name']), ENT_QUOTES, 'UTF-8');
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $review_details = htmlspecialchars(trim($_POST['review_details']), ENT_QUOTES, 'UTF-8');
    $rating = intval($_POST['rating']);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['status' => 'error', 'message' => 'Please enter a valid email address.']);
        exit;
    }
    $posted_by = "admin";
    $post_status = "approved";

    $query = "INSERT INTO user_reviews (first_name, last_name, email, review_details, rating, posted_by, post_status) VALUES (?, ?, ?, ?, ?,?,?)";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param('ssssiss', $first_name, $last_name, $email, $review_details, $rating, $posted_by, $post_status);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Thank you for your review! We appreciate your feedback.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to submit your review. Please try again later.']);
    }

    $stmt->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
}
