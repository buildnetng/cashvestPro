<?php

require_once '../config.php';
require_once '../../../vendor/mailer.php';
$response = ['status' => 'error', 'message' => 'Invalid request.'];

  

if (isset($_POST['action']) && isset($_POST['id'])) {
    $id = (int)$_POST['id'];
    $action = $_POST['action'];

    // Fetch the current status of the application
    $query = "SELECT `status`,`email`,`job_title` FROM `job_applications` WHERE `id` = $id";
    $result = $mysqli->query($query);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $currentStatus = $row['status'];
       

        if ($action === 'approve' || $action === 'reject') {
            if (($action === 'approve' && $currentStatus === 'Approved') || ($action === 'reject' && $currentStatus === 'Rejected')) {
                $response['message'] = "This application has already been $currentStatus.";
            } else {
                if ($action === 'reject' && isset($_POST['reason'])) {
                    $reasonForRejection = $mysqli->real_escape_string($_POST['reason']);

                    // Update the status in the database
                    $query = "UPDATE `job_applications` SET `status` = 'Rejected', `rejection_reason` = '$reasonForRejection' WHERE `id` = $id";

                    if ($mysqli->query($query)) {
                        // Send rejection email
                        $userID = $id;
                        $user_email = $row['email'];
                        $job_title =  $row['job_title' ];
                        $subject = "Application Status Update";
                        $message = "
                         <p> Dear $user_email,</p>
                         <p>Thank you for applying for the position of a $job_title through Noble Teachers. After reviewing your application, we found that $reasonForRejection</p>

                         <p>Thank you for considering our job application. If you have any questions or need further information, please don't hesitate to contact us at <a href='mailto:info@example.com'>info@example.com</a>.</p>



Best regards,  
Noble Teachers</p>
                        
                        Dear Applicant,\n\nYour application has been rejected for the following reason:\n\n" . $reasonContents;
                        $headers = "From: no-reply@example.com"; // Replace with your email header


                        $isSent = sendEmail($user_email, $subject, $reasonForRejection);

                        if (sendEmail($userID, $reasonForRejection, $reasonForRejection)) {
                            $response['status'] = 'success';
                            $response['message'] = "Application rejected and email sent successfully.";
                        } else {
                            $response['message'] = "Application rejected, but there was an error sending the email.";
                        }
                    } else {
                        $response['message'] = "Error updating application status: " . $mysqli->error;
                    }
                } else {
                    $status = $action === 'approve' ? 'Approved' : 'Rejected';
                    $query = "UPDATE `job_applications` SET `status` = '$status' WHERE `id` = $id";

                    if ($mysqli->query($query)) {
                        $response['status'] = 'success';
                        $response['message'] = "Application $status successfully.";
                    } else {
                        $response['message'] = "Error updating application status: " . $mysqli->error;
                    }
                }
            }
        } elseif ($action === 'delete') {
            $query = "DELETE FROM `job_applications` WHERE `id` = $id";

            if ($mysqli->query($query)) {
                $response['status'] = 'success';
                $response['message'] = "Application deleted successfully.";
            } else {
                $response['message'] = "Error deleting application: " . $mysqli->error;
            }
        }
    } else {
        $response['message'] = "Application not found.";
    }
}

echo json_encode($response);
?>
