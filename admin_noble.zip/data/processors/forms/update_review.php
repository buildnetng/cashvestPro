<?php
require_once '../config.php'; // Include your database configuration file

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reviewId = intval($_POST['review_id']);
    $reviewText = $mysqli->real_escape_string($_POST['review_text']);
    $rating = intval($_POST['rating']);

    // Fetch existing review data from the database
    $query = "SELECT `review_details`, `rating` FROM `user_reviews` WHERE `id` = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("i", $reviewId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $existingReview = $result->fetch_assoc();

        // Check if the submitted data matches the existing data
        if ($existingReview['review_details'] === $reviewText && intval($existingReview['rating']) === $rating) {
            echo json_encode(['success' => false, 'message' => "Sorry, you can't update an old record because no changes have been made to the data."]);
        } else {
            // Proceed with the update if there are changes
            $updateQuery = "UPDATE `user_reviews` SET `review_details` = ?, `rating` = ? WHERE `id` = ?";
            $updateStmt = $mysqli->prepare($updateQuery);
            $updateStmt->bind_param("sii", $reviewText, $rating, $reviewId);

            if ($updateStmt->execute()) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to update review.']);
            }

            $updateStmt->close();
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Review not found.']);
    }

    $stmt->close();
}

$mysqli->close();
