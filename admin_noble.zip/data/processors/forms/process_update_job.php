<?php
require_once '../config.php';

// Initialize response array
$response = ['status' => 'error', 'messages' => []];

// Check if POST data is set
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the job details from the POST request
    $jobId = isset($_POST['id']) ? intval($_POST['id']) : null;
    $jobTitle = isset($_POST['job_title']) ? trim($_POST['job_title']) : '';
    $jobLocation = isset($_POST['job_location']) ? trim($_POST['job_location']) : '';
    $description = isset($_POST['description']) ? trim($_POST['description']) : '';
    $applicationDeadline = isset($_POST['application_deadline']) ? trim($_POST['application_deadline']) : '';
    $schoolName = isset($_POST['school_name']) ? trim($_POST['school_name']) : '';
    $experience = isset($_POST['experience']) ? trim($_POST['experience']) : '';
    $degree = isset($_POST['degree']) ? trim($_POST['degree']) : '';
    $jobType = isset($_POST['job_type']) ? trim($_POST['job_type']) : '';
    $companyName = isset($_POST['company_name']) ? trim($_POST['company_name']) : '';
    $contactEmail = isset($_POST['contact_email']) ? trim($_POST['contact_email']) : '';
    $salaryRange = isset($_POST['salary_range']) ? trim($_POST['salary_range']) : '';

    // Validate the input
    if (!$jobId) {
        $response['messages'][] = 'Invalid job ID.';
    }
    if (empty($jobTitle)) {
        $response['messages'][] = 'Job title is required.';
    }
    if (empty($jobLocation)) {
        $response['messages'][] = 'Job location is required.';
    }
    if (empty($description)) {
        $response['messages'][] = 'Job description is required.';
    }
   
   
   
    if (empty($jobType)) {
        $response['messages'][] = 'Job type is required.';
    }
   
    if (empty($contactEmail) || !filter_var($contactEmail, FILTER_VALIDATE_EMAIL)) {
        $response['messages'][] = 'Valid contact email is required.';
    }
    if (empty($salaryRange)) {
        $response['messages'][] = 'Salary range is required.';
    }

    // If there are no validation errors, proceed with the update
    if (empty($response['messages'])) {
        // Prepare the update statement
        $stmt = $mysqli->prepare("
            UPDATE jobs 
            SET job_title = ?, job_location = ?, description = ?, application_deadline = ?, 
                school_name = ?, experience = ?, degree = ?, job_type = ?, 
                company_name = ?, contact_email = ?, salary_range = ? 
            WHERE id = ?
        ");
        $stmt->bind_param("sssssssssssi", 
            $jobTitle, $jobLocation, $description, $applicationDeadline, 
            $schoolName, $experience, $degree, $jobType, 
            $companyName, $contactEmail, $salaryRange, $jobId
        );

        // Execute the statement
        if ($stmt->execute()) {
            $response['status'] = 'success';
            $response['messages'][] = 'Job updated successfully.';
        } else {
            $response['messages'][] = 'Error updating job: ' . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    }
} else {
    $response['messages'][] = 'Invalid request method.';
}

// Output the response as JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
