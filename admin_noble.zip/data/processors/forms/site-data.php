<?php
require "../config.php";

// Function to sanitize user input
function sanitizeInput($input)
{
    return htmlspecialchars(strip_tags(trim($input)));
}

// Function to create directory if it doesn't exist
function createDirectory($path)
{
    if (!file_exists($path)) {
        mkdir($path, 0777, true);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and fetch POST data
    $site_title = sanitizeInput($_POST['site_title']);
    $meta_keywords = sanitizeInput($_POST['meta_keywords']);
    $meta_desc = sanitizeInput($_POST['meta_desc']);
    $meta_author = sanitizeInput($_POST['meta_author']);
    $theme_color = sanitizeInput($_POST['theme_color']);
    $company_phone = sanitizeInput($_POST['company_phone']);
    $company_email = sanitizeInput($_POST['company_email']);
    $company_address = sanitizeInput($_POST['company_address']);
    $gmail_account = sanitizeInput($_POST['gmail_account']);
    $gmail_password = sanitizeInput($_POST['gmail_password']);
    $reply_to_address = sanitizeInput($_POST['reply_to_address']);
    $pagination_number = sanitizeInput($_POST['pagination_number']);
    $site_url = sanitizeInput($_POST['site_url']);
    $account_url = sanitizeInput($_POST['account_url']);
    $multiple_jobs = sanitizeInput($_POST['multiple_jobs']);
    $same_cv = isset($_POST['same_cv']) ? sanitizeInput($_POST['same_cv']) : 'no';
    $allow_feedback = sanitizeInput($_POST['allow_feedback']);
    $mentainace_mode = sanitizeInput($_POST['mentainace_mode']);

    // Define the uploads directory path
    $uploads_dir = __DIR__ . '/../../uploads';

    // Create the uploads directory if it doesn't exist
    createDirectory($uploads_dir);

    // Handle file uploads
    $logo = $_FILES['logo']['name'] ? 'uploads/' . basename($_FILES['logo']['name']) : null;
    $favicon = $_FILES['favicon']['name'] ? 'uploads/' . basename($_FILES['favicon']['name']) : null;

    if ($logo) {
        $logo_path = $uploads_dir . '/' . basename($logo);
        move_uploaded_file($_FILES['logo']['tmp_name'], $logo_path);
    }

    if ($favicon) {
        $favicon_path = $uploads_dir . '/' . basename($favicon);
        move_uploaded_file($_FILES['favicon']['tmp_name'], $favicon_path);
    }

    // Trim out '../../' from the paths before saving to the database
    if ($logo) {
        $logo = str_replace('../../', '', $logo);
    }

    if ($favicon) {
        $favicon = str_replace('../../', '', $favicon);
    }

    // Check if there's already a record in the table
    $query = "SELECT * FROM system_setup WHERE id = 1";
    $result = mysqli_query($mysqli, $query);

    if (mysqli_num_rows($result) > 0) {
        // Update the existing record
        $sql = "UPDATE system_setup SET
                site_title = '$site_title',
                meta_keywords = '$meta_keywords',
                meta_desc = '$meta_desc',
                meta_author = '$meta_author',
                theme_color = '$theme_color',
                company_phone = '$company_phone',
                company_email = '$company_email',
                company_address = '$company_address',
                gmail_account = '$gmail_account',
                gmail_password = '$gmail_password',
                reply_to_address = '$reply_to_address',
                pagination_number = '$pagination_number',
                logo = IFNULL('$logo', logo),
                favicon = IFNULL('$favicon', favicon),
                site_url = '$site_url',
                account_url = '$account_url',
                multiple_jobs = '$multiple_jobs',
                same_cv = '$same_cv',
                allow_feedback = '$allow_feedback',
                mentainace_mode = '$mentainace_mode'
                WHERE id = 1";
    } else {
        // Insert a new record
        $sql = "INSERT INTO system_setup 
                (site_title, meta_keywords, meta_desc, meta_author, theme_color, company_phone, company_email, company_address, gmail_account, gmail_password, reply_to_address, pagination_number, logo, favicon, site_url, account_url, multiple_jobs, same_cv, allow_feedback, mentainace_mode)
                VALUES
                ('$site_title', '$meta_keywords', '$meta_desc', '$meta_author', '$theme_color', '$company_phone', '$company_email', '$company_address', '$gmail_account', '$gmail_password', '$reply_to_address', '$pagination_number', '$logo', '$favicon', '$site_url', '$account_url', '$multiple_jobs', '$same_cv', '$allow_feedback', '$mentainace_mode')";
    }

    if (mysqli_query($mysqli, $sql)) {
        echo 'success';
    } else {
        echo 'Error: ' . mysqli_error($mysqli);
    }

    mysqli_close($mysqli);
}
