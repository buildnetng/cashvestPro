<?php
require_once '../config.php'; 

header('Content-Type: application/json');

$response = [
    'status' => 'error',
    'messages' => []
];

if (isset($_POST['id']) && filter_var($_POST['id'], FILTER_VALIDATE_INT)) {
    $jobId = $_POST['id'];

    $mysqli->begin_transaction();

    try {
        if ($stmt = $mysqli->prepare("DELETE FROM job_comments WHERE job_id = ?")) {
            $stmt->bind_param("i", $jobId);
            $stmt->execute();
            $stmt->close();
        } else {
            throw new Exception('Failed to prepare statement for deleting job_comments.');
        }

        $checkTable = $mysqli->query("SHOW TABLES LIKE 'job_reports'");
        if ($checkTable && $checkTable->num_rows > 0) {
            $stmt = $mysqli->prepare("DELETE FROM job_reports WHERE job_id = ?");
            $stmt->bind_param("i", $jobId);
            $stmt->execute();
            $stmt->close();
        }

        if ($stmt = $mysqli->prepare("DELETE FROM jobs WHERE id = ?")) {
            $stmt->bind_param("i", $jobId);
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                $response['status'] = 'success';
                $response['messages'][] = 'Job deleted successfully.';
                $mysqli->commit(); 
            } else {
                $response['messages'][] = 'No job found with the given ID.';
                $mysqli->rollback(); 
            }
            $stmt->close();
        } else {
            throw new Exception('Failed to prepare statement for deleting jobs.');
        }
    } catch (Exception $e) {
        $mysqli->rollback();
        $response['messages'][] = 'Failed to delete job due to an error: ' . $e->getMessage();
    }
} else {
    $response['messages'][] = 'Invalid job ID.';
}
echo json_encode($response);
