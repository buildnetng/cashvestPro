<?php
require_once '../config.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $id = intval($_GET['id']);
    $query = "DELETE FROM `user_reviews` WHERE `id` = $id";
    if ($mysqli->query($query)) {
        echo json_encode(['status' => 'success', 'message' => 'Review deleted successfully!']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to delete review.']);
    }
    $mysqli->close();
}
