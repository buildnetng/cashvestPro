<?php
require "../config.php";

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $job_id = intval($_GET['id']);

    // Prepare and execute query to fetch job details
    $stmt = $mysqli->prepare("SELECT `job_title`, `job_location`, `school_name`, `description`, `application_deadline`, `experience`, `degree`, `salary_range`, `job_type`, `company_name`, `contact_email`, `posted_time`, `post_status`, `date_created` FROM `jobs` WHERE `id` = ?");
    $stmt->bind_param("i", $job_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $job = $result->fetch_assoc();
        // Successfully fetched job details
    } else {
        // Job not found
        header("Location: job_listing");
        exit;
    }

    $stmt->close();
} else {
    // Invalid or missing job ID
    header("Location: job_listing");
    exit;
}

$mysqli->close();
