<?php

require_once '../config.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];

    // Prepare and execute the query
    $stmt = $mysqli->prepare("SELECT `job_id`, `name`, `email`, `phone`, `location`, `status`, `resume`, `cover_letter`, `additional_info`, `date_applied`, `country`, `state`, `city`, `zipcode` FROM `job_applications` WHERE `id` = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch the data
    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
        echo json_encode($data);
    } else {
        echo json_encode(['error' => 'No data found']);
    }

    $stmt->close();
    $mysqli->close();
}
?>
