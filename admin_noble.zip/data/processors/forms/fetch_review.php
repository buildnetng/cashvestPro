<?php
require_once '../config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id'])) {
    $reviewId = $_POST['id'];

    // Prepare and execute the query to fetch the review data
    $stmt = $conn->prepare("SELECT id, first_name, last_name, email, review_details, rating FROM reviews WHERE id = ?");
    $stmt->bind_param("i", $reviewId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $review = $result->fetch_assoc();
        echo json_encode(['status' => 'success', 'data' => $review]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Review not found']);
    }

    $stmt->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
}

$conn->close();
