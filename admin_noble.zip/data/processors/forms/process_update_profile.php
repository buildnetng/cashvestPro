<?php
session_start();
header('Content-Type: application/json');

// Initialize response array
$response = ['status' => 'error', 'messages' => []];

// Check if the user is logged in and required POST parameters are set
if (isset($_SESSION['user_id']) && isset($_POST['first_name']) && isset($_POST['last_name']) && isset($_POST['email'])) {
    // Sanitize and trim input
    $firstName = trim($_POST['first_name']);
    $lastName = trim($_POST['last_name']);
    $email = trim($_POST['email']);

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $response['messages'][] = 'Invalid email format.';
    } else {
        require "../config.php"; // Database configuration file

        // Check for connection errors
        if ($mysqli->connect_error) {
            $response['messages'][] = 'Database connection failed: ' . $mysqli->connect_error;
        } else {
            // Combine first and last names into full_name
            $fullName = $firstName . ' ' . $lastName;

            // Check if the email has been changed
            $stmt = $mysqli->prepare('SELECT `email` FROM `users` WHERE `id` = ?');
            $stmt->bind_param('i', $_SESSION['user_id']);
            $stmt->execute();
            $stmt->bind_result($currentEmail);
            $stmt->fetch();
            $stmt->close();

            if ($email !== $currentEmail) {
                $response['messages'][] = 'To change your email, please contact the administrators.';
            } else {
                // Prepare and execute query to update user profile
                $stmt = $mysqli->prepare('UPDATE `users` SET `full_name` = ? WHERE `id` = ?');
                $stmt->bind_param('si', $fullName, $_SESSION['user_id']);

                if ($stmt->execute()) {
                    $response['status'] = 'success';
                    $response['messages'][] = 'Profile updated successfully!';
                } else {
                    $response['messages'][] = 'Failed to update profile.';
                }

                $stmt->close();
            }

            $mysqli->close();
        }
    }
} else {
    $response['messages'][] = 'All fields are required.';
}

// Output the response as JSON
echo json_encode($response);
