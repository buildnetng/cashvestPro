<?php
require_once '../config.php';

header('Content-Type: application/json'); // Ensure the response is JSON

$response = ['status' => 'error', 'message' => 'Invalid request'];

if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    $sql = "DELETE FROM blog_posts WHERE id = ?";
    if ($stmt = $mysqli->prepare($sql)) {
        $stmt->bind_param('i', $id);

        if ($stmt->execute()) {
            $response = ['status' => 'success'];
        } else {
            $response = ['status' => 'error', 'message' => 'Failed to delete post: ' . $stmt->error];
        }

        $stmt->close();
    } else {
        $response = ['status' => 'error', 'message' => 'Failed to prepare SQL statement: ' . $mysqli->error];
    }
}

echo json_encode($response);
$mysqli->close();
