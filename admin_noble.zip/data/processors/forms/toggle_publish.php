<?php
require_once '../config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);
    $action = $mysqli->real_escape_string($_POST['action']);
    $postStatus = ($action === 'publish') ? 'approved' : 'pending';

    $query = "UPDATE `user_reviews` SET `post_status` = '$postStatus' WHERE `id` = $id";
    if ($mysqli->query($query)) {
        echo json_encode(['status' => 'success', 'message' => ($action === 'publish') ? 'Review published successfully!' : 'Review unpublished successfully!']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to update review status.']);
    }
    $mysqli->close();
}
