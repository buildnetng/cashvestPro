<?php
require_once '../config.php';

$uploadDir = '../../../uploads/blog_post/';

// Ensure the directory exists and create it if necessary
if (!is_dir($uploadDir)) {
    if (!mkdir($uploadDir, 0777, true)) {
        echo json_encode(['status' => 'error', 'message' => 'Failed to create the blog_post directory.']);
        exit;
    }
}

$response = ['status' => 'error', 'message' => ''];

if (isset($_POST['blog_title']) && !empty(trim($_POST['blog_title'])) && isset($_POST['description']) && !empty(trim($_POST['description'])) && isset($_FILES['blog_image'])) {

    $blog_title = trim($_POST['blog_title']);
    $description = trim($_POST['description']);

    $imageName = $_FILES['blog_image']['name'];
    $imageTmpName = $_FILES['blog_image']['tmp_name'];
    $imageSize = $_FILES['blog_image']['size'];
    $imageError = $_FILES['blog_image']['error'];

    if ($imageError === 0) {
        $imageExt = strtolower(pathinfo($imageName, PATHINFO_EXTENSION));
        $allowedExt = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($imageExt, $allowedExt)) {
            $newImageName = uniqid('blog_', true) . '.' . $imageExt;
            $imagePath = $uploadDir . $newImageName;

            if (move_uploaded_file($imageTmpName, $imagePath)) {
                // Prepare and execute SQL insert query
                $sql = "INSERT INTO blog_posts (blog_title, description, image_path) VALUES (?, ?, ?)";
                if ($stmt = $mysqli->prepare($sql)) {
                    $safeImagePath = str_replace('../../../', '', $imagePath); // Store relative path in database
                    $stmt->bind_param('sss', $blog_title, $description, $safeImagePath);

                    if ($stmt->execute()) {
                        echo json_encode(['status' => 'success', 'message' => 'Blog post successfully submitted with image!']);
                    } else {
                        echo json_encode(['status' => 'error', 'message' => 'Failed to insert blog post into the database: ' . $stmt->error]);
                    }

                    $stmt->close();
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'Failed to prepare the SQL statement: ' . $mysqli->error]);
                }
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Failed to upload the image.']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Invalid image file type. Only JPG, JPEG, PNG, and GIF are allowed.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error uploading the image. Please try again.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'All fields are required, including an image.']);
}

$mysqli->close();
