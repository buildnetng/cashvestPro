<?php
require_once '../config.php'; // Ensure this file connects to the database

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']); // Get ID from POST data

    // Prepare the DELETE statement
    $stmt = $mysqli->prepare("DELETE FROM `subscribers` WHERE `id` = ?");
    $stmt->bind_param('i', $id);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Subscriber deleted successfully']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to delete subscriber']);
    }

    $stmt->close(); // Close the statement
    $mysqli->close(); // Close the connection
}
