<?php
require_once '../config.php';

$query = "SELECT id, first_name, last_name, email, reason, school_name, person_name, message, created_at FROM contact_messages";
$result = $mysqli->query($query);

$contacts = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $contacts[] = $row;
    }
    echo json_encode($contacts);
} else {
    echo json_encode(['error' => $mysqli->error]);
}

$mysqli->close();
