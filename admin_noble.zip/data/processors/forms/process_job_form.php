<?php
session_start();
header('Content-Type: application/json');

// Initialize response array
$response = ['status' => 'error', 'messages' => []];

// Database connection
require "../config.php";

// Check if all required POST parameters are set
if (isset($_POST['job_title'], $_POST['job_location'], $_POST['school_name'], $_POST['description'], $_POST['application_deadline'], $_POST['experience'], $_POST['degree'], $_POST['salary_range'], $_POST['job_type'], $_POST['company_name'], $_POST['contact_email'])) {
    $jobTitle = trim($_POST['job_title']);
    $jobLocation = trim($_POST['job_location']);
    $schoolName = trim($_POST['school_name']);
    $description = trim($_POST['description']);
    $applicationDeadline = trim($_POST['application_deadline']);
    $experience = trim($_POST['experience']);
    $degree = trim($_POST['degree']);
    $salaryRange = trim($_POST['salary_range']);
    $jobType = trim($_POST['job_type']);
    $companyName = trim($_POST['company_name']);
    $contactEmail = trim($_POST['contact_email']);

    // Validate data
    if (empty($jobTitle) || empty($jobLocation) || empty($schoolName) || empty($description) || empty($salaryRange) || empty($jobType)  ) {
        $response['messages'][] = 'All fields are required.';
    } else {
        // Prepare and execute query to insert data into database
        $stmt = $mysqli->prepare('INSERT INTO jobs (job_title, job_location, school_name, description, application_deadline, experience, degree, salary_range, job_type, company_name, contact_email) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->bind_param('sssssssssss', $jobTitle, $jobLocation, $schoolName, $description, $applicationDeadline, $experience, $degree, $salaryRange, $jobType, $companyName, $contactEmail);

        if ($stmt->execute()) {
            $response['status'] = 'success';
            $response['messages'][] = 'Job listing added successfully.';
        } else {
            $response['messages'][] = 'Failed to add job listing.';
        }

        $stmt->close();
    }
} else {
    $response['messages'][] = 'All fields are required.';
}

// Close the database connection
$mysqli->close();

// Output the response as JSON
echo json_encode($response);
