<?php
require_once '../../../vendor/mailer.php';

// Set the response header to JSON format
header('Content-Type: application/json');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve and sanitize the input data
    $subject = trim($_POST['subject'] ?? '');
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $content = html_entity_decode($_POST['description'] ?? '', ENT_QUOTES, 'UTF-8');

    // Validate required fields
    if (!$subject) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Subject is required.'
        ]);
        exit;
    }
    if (!$email) {
        echo json_encode([
            'status' => 'error',
            'message' => 'A valid email address is required.'
        ]);
        exit;
    }
    if (!$content) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Email content is required.'
        ]);
        exit;
    }

    // Attempt to send the email
    $isSent = sendEmail($subject, $email, $content);

    // Send a success or failure response
    if ($isSent) {
        echo json_encode([
            'status' => 'success',
            'message' => 'Email has been sent successfully!'
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Failed to send email. Please try again.'
        ]);
    }
} else {
    // Return error if not a POST request
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request method. Only POST is allowed.'
    ]);
}
