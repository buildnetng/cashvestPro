<?php
require_once '../config.php';

session_start();

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'messages' => ['Invalid request method.']]);
    exit;
}

// Check if the registration flag is set
if (!isset($_POST['registration']) || $_POST['registration'] !== '1') {
    echo json_encode(['status' => 'error', 'messages' => ['Invalid registration attempt.']]);
    exit;
}

if ($_SERVER["HTTP_HOST"] != "noble-dashboard.test") {
    // reCAPTCHA Verification
    $recaptcha = $_POST['g-recaptcha-response'] ?? '';
    $secretKey = '6LcE3DIqAAAAACvbww3paTc5LzwpxJXbXBlqfsNN'; // Replace with your actual secret key
    $recaptchaURL = "https://www.google.com/recaptcha/api/siteverify?secret=$secretKey&response=$recaptcha";

    $response = file_get_contents($recaptchaURL);
    $responseKeys = json_decode($response, true);

    if (intval($responseKeys["success"]) !== 1) {
        echo json_encode(['status' => 'error', 'messages' => ['Please confirm you\'re not a robot by completing the reCAPTCHA test. If this error persists, please wait for the reCAPTCHA token to expire before you try again.']]);
        exit; // Exit script if CAPTCHA fails
    }
}

// Input Validation
$fullName = trim($_POST['full_name'] ?? '');
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$password = trim($_POST['password'] ?? '');
$confirmPassword = trim($_POST['confirm_password'] ?? '');

$errors = [];

// Split Full Name for Validation
$names = explode(' ', $fullName, 2);
$firstName = $names[0] ?? '';
$lastName = $names[1] ?? '';

// Validate First and Last Name
if (empty($firstName)) {
    $errors[] = 'First name is required.';
}
if (empty($lastName)) {
    $errors[] = 'Last name is required.';
}

// Validate Email
if (empty($email)) {
    $errors[] = 'Email address cannot be empty.';
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Invalid email address format.';
}

// Validate Password
if (empty($password)) {
    $errors[] = 'Password is required.';
} elseif (
    strlen($password) < 8 ||
    !preg_match('/[A-Z]/', $password) ||
    !preg_match('/[a-z]/', $password) ||
    !preg_match('/[0-9]/', $password) ||
    !preg_match('/[\W_]/', $password)
) {
    $errors[] = 'Password must be at least 8 characters long and include uppercase, lowercase, numbers, and special characters.';
}

// Confirm Password
if ($password !== $confirmPassword) {
    $errors[] = 'Passwords do not match.';
}

// Check if there are validation errors
if (!empty($errors)) {
    echo json_encode(['status' => 'error', 'messages' => $errors]);
    exit;
}

// Check if Email Already Exists
$stmt = $mysqli->prepare("SELECT id FROM users WHERE email = ?");
if (!$stmt) {
    echo json_encode(['status' => 'error', 'messages' => ['Database error: ' . $mysqli->error]]);
    exit;
}
$stmt->bind_param('s', $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo json_encode(['status' => 'error', 'messages' => ['Email is already registered. Consider resetting your password or contacting support.']]);
    $stmt->close();
    exit;
}
$stmt->close();

// Helper Functions
function generateCode($length = 6)
{
    return substr(bin2hex(random_bytes($length)), 0, $length);
}

// Prepare User Data
$hashedPassword = password_hash($password, PASSWORD_BCRYPT);
$supportPIN = generateCode(6);
$emailVerified = 0;
$profileUpdated = 0;
$userType = 'user';
$userIpAddress = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
$browserData = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
$dateIn = (new DateTime())->format('Y-m-d H:i:s');
$lastVisit = $dateIn;

// Recombine Names for Full Name
$fullName = $firstName . ' ' . $lastName;

// Insert New User
$stmt = $mysqli->prepare("INSERT INTO users (full_name, email, password, support_pin, email_verified, profile_updated, user_type, user_ip_address, browser_data, date_in, last_visit) 
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

if (!$stmt) {
    echo json_encode(['status' => 'error', 'messages' => ['Database error: ' . $mysqli->error]]);
    exit;
}

$stmt->bind_param('sssssiissss', $fullName, $email, $hashedPassword, $supportPIN, $emailVerified, $profileUpdated, $userType, $userIpAddress, $browserData, $dateIn, $lastVisit);

if ($stmt->execute()) {
    $userId = $stmt->insert_id;
    $_SESSION['user_id'] = $userId;
    $_SESSION['user_email'] = $email;

    echo json_encode(['status' => 'success', 'messages' => ['Registration successful!']]);
} else {
    echo json_encode(['status' => 'error', 'messages' => ['Database error: ' . $stmt->error]]);
}

$stmt->close();
$mysqli->close();
