<?php
require_once '../config.php';
require_once '../../../vendor/mailer.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['email'])) {
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(['status' => 'error', 'messages' => ['Invalid email address.']]);
            exit;
        }

        // Replace 'email' with the correct column name
        $stmt = $mysqli->prepare("SELECT id FROM users WHERE email = ?");
        if ($stmt === false) {
            echo json_encode(['status' => 'error', 'messages' => ['Database error: Failed to prepare statement.']]);
            exit;
        }
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows === 0) {
            echo json_encode(['status' => 'error', 'messages' => ['Email not found.']]);
            session_unset();
            session_destroy();
            exit;
        }

        $stmt->bind_result($userId);
        $stmt->fetch();
        $stmt->close();

        // Generate reset token and expiration
        $resetToken = bin2hex(random_bytes(16));
        $resetTokenExpiration = date('Y-m-d H:i:s', strtotime('+1 hour')); // Token valid for 1 hour

        // Update user record with reset token and expiration
        $stmt = $mysqli->prepare("UPDATE users SET reset_token = ?, reset_token_expiration = ? WHERE id = ?");
        if ($stmt === false) {
            echo json_encode(['status' => 'error', 'messages' => ['Database error: Failed to prepare statement.']]);
            exit;
        }
        $stmt->bind_param('ssi', $resetToken, $resetTokenExpiration, $userId);
        $stmt->execute();

        // Send reset email
        $resetLink = "https://yourdomain.com/reset_password.php?token=$resetToken";
        $subject = 'Password Reset Request';
        $message = "To reset your password, please click the following link: $resetLink";
        mail($email, $subject, $message);

        echo json_encode(['status' => 'success', 'messages' => ['Password reset email has been sent.']]);
    } else {
        echo json_encode(['status' => 'error', 'messages' => ['Invalid request.']]);
    }
} else {
    echo json_encode(['status' => 'error', 'messages' => ['Invalid request method.']]);
}

$mysqli->close();
