<?php
require_once '../config.php';
require_once '../../../vendor/mailer.php';

session_start();
// Check if the user is logged in
if (isset($_SESSION['user_id']) && isset($_SESSION['user_email'])) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Retrieve and sanitize inputs
        $verificationCode = filter_input(INPUT_POST, 'verification_code', FILTER_DEFAULT);
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);

        if (empty($verificationCode) || empty($email)) {
            echo json_encode(['status' => 'error', 'messages' => ['Invalid code or email.']]);
            exit;
        }

        // Prepare SQL statement to check if the email is already verified
        $stmt = $mysqli->prepare("SELECT id, email_verified FROM users WHERE email = ? AND verification_code = ?");
        if ($stmt) {
            $stmt->bind_param('ss', $email, $verificationCode);
            $stmt->execute();
            $stmt->store_result();
            $stmt->bind_result($userId, $emailVerified);
            $stmt->fetch();

            if ($stmt->num_rows === 1) {
                if ($emailVerified == 1) {
                    // If email is already verified
                    echo json_encode(['status' => 'error', 'messages' => ['Email is already verified.']]);
                } else {
                    // Update the email verification status
                    $updateStmt = $mysqli->prepare("UPDATE users SET email_verified = 1 WHERE email = ?");
                    if ($updateStmt) {
                        $updateStmt->bind_param('s', $email);
                        if ($updateStmt->execute()) {
                            // Send a confirmation email
                            $subject = "Email Verified Successfully";
                            $verificationMessage = "
                                <p>Hello,</p>
                                <p>Your email has been verified successfully. Thank you for confirming your account.</p>
                                <p>If you have any questions, feel free to reach out to our support team.</p>
                                <p>Regards,<br>Your Company</p>
                            ";

                            $sendVerification = sendEmail($email, $subject, $verificationMessage);

                            if ($sendVerification) {
                                echo json_encode(['status' => 'success', 'messages' => ['Email verified successfully!']]);
                            } else {
                                echo json_encode(['status' => 'error', 'messages' => ['Failed to send verification email.']]);
                            }
                        } else {
                            echo json_encode(['status' => 'error', 'messages' => ['Failed to update email verification status.']]);
                        }
                        $updateStmt->close();
                    } else {
                        echo json_encode(['status' => 'error', 'messages' => [$mysqli->error]]);
                    }
                }
            } else {
                echo json_encode(['status' => 'error', 'messages' => ['Invalid verification code or email.']]);
            }
            $stmt->close();
        } else {
            echo json_encode(['status' => 'error', 'messages' => [$mysqli->error]]);
        }
    } else {
        echo json_encode(['status' => 'error', 'messages' => ['Invalid request method.']]);
    }
} else {
    echo json_encode(['status' => 'error', 'messages' => ['User is not logged in.']]);
}

// Close the database connection
$mysqli->close();
