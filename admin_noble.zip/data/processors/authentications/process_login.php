<?php
require_once '../config.php';

session_start();

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'messages' => ['Invalid request method.']]);
    exit;
}

// Check if the login flag is set
if (!isset($_POST['login']) || $_POST['login'] !== '1') {
    echo json_encode(['status' => 'error', 'messages' => ['Invalid login attempt.']]);
    exit;
}

if ($_SERVER["HTTP_HOST"] != "noble-dashboard.test") {
    // reCAPTCHA Verification
    $recaptcha = $_POST['g-recaptcha-response'] ?? '';
    $secretKey = '6LcE3DIqAAAAACvbww3paTc5LzwpxJXbXBlqfsNN'; // Secure this key in an environment variable or config file
    $recaptchaURL = "https://www.google.com/recaptcha/api/siteverify?secret=$secretKey&response=$recaptcha";

    $response = @file_get_contents($recaptchaURL);
    if ($response === FALSE) {
        echo json_encode(['status' => 'error', 'messages' => ['Failed to verify reCAPTCHA.']]);
        exit;
    }

    $responseKeys = json_decode($response, true);
    if (intval($responseKeys["success"]) !== 1) {
        echo json_encode(['status' => 'error', 'messages' => ['Please complete the reCAPTCHA.']]);
        exit;
    }
}

// Input Validation
$email = trim($_POST['email'] ?? '');
$password = trim($_POST['password'] ?? '');

$errors = [];

// Validate Email
if (empty($email)) {
    $errors[] = 'Email address cannot be empty.';
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Invalid email address format.';
}

// Validate Password
if (empty($password)) {
    $errors[] = 'Password is required.';
}

// Check if there are validation errors
if (!empty($errors)) {
    echo json_encode(['status' => 'error', 'messages' => $errors]);
    exit;
}

// Check User Credentials
$stmt = $mysqli->prepare("SELECT id, password FROM users WHERE email = ?");
if (!$stmt) {
    echo json_encode(['status' => 'error', 'messages' => ['Database error: ' . $mysqli->error]]);
    exit;
}
$stmt->bind_param('s', $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    echo json_encode(['status' => 'error', 'messages' => ['Invalid email or password.']]);
    $stmt->close();
    exit;
}

$stmt->bind_result($id, $hashedPassword); // Bind the id and password from the database
$stmt->fetch();

if (!password_verify($password, $hashedPassword)) {
    echo json_encode(['status' => 'error', 'messages' => ['Invalid email or password.']]);
    $stmt->close();
    exit;
}

// Successful Login
$_SESSION['user_id'] = $id;
$_SESSION['user_email'] = $email;
$_SESSION['LAST_ACTIVITY'] = time();


echo json_encode(['status' => 'success', 'messages' => ['Login successful!']]);

$stmt->close();
$mysqli->close();
