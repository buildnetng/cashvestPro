<?php
require_once '../config.php';
require_once '../../../vendor/mailer.php';

session_start();

if (isset($_POST['email'])) {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);

    // Generate a new verification code
    $verificationCode = rand(100000, 999999);

    // Prepare SQL statement to update the verification code
    $stmt = $mysqli->prepare("UPDATE users SET verification_code = ? WHERE email = ?");
    if ($stmt) {
        $stmt->bind_param('ss', $verificationCode, $email);
        if ($stmt->execute()) {
            // Send a new verification email
            $subject = "Resend Verification Code";
            $verificationMessage = "
                <p>Hello,</p>
                <p>We have resent your verification code. Your new code is: <strong>{$verificationCode}</strong></p>
                <p>Please enter this code in the application to verify your email address.</p>
                <p>Regards,<br>Your Company</p>
            ";

            if (sendEmail($email, $subject, $verificationMessage)) {
                echo json_encode(['status' => 'success', 'message' => 'Verification email resent successfully.']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Failed to send verification email.']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to update verification code.']);
        }
        $stmt->close();
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $mysqli->error]);
    }
} else {
  echo json_encode(['status' => 'error', 'messages' => ['User is not logged in.']]);
}

// Close the database connection
$mysqli->close();
