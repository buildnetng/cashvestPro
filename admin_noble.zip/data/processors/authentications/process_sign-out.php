<?php
session_unset();
session_destroy();
header("Location: auth?loggedout=yes");
exit;
