<?php
require_once '../config.php';
require_once '../../../vendor/mailer.php';

session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['token']) && isset($_POST['password'])) {
        $token = $_POST['token'];
        $password = $_POST['password'];

        // Validate the password
        if (empty($password)) {
            echo json_encode(['status' => 'error', 'messages' => ['Password cannot be empty.']]);
            exit;
        }

        // Check if token is valid
        $stmt = $mysqli->prepare("SELECT id, reset_token_expiration FROM users WHERE reset_token = ?");
        $stmt->bind_param('s', $token);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows === 0) {
            echo json_encode(['status' => 'error', 'messages' => ['Invalid reset token.']]);
            exit;
        }

        $stmt->bind_result($userId, $resetTokenExpiration);
        $stmt->fetch();
        $stmt->close();

        // Check if token has expired
        if (new DateTime() > new DateTime($resetTokenExpiration)) {
            echo json_encode(['status' => 'error', 'messages' => ['Reset token has expired.']]);
            exit;
        }

        // Hash the new password
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        // Update the password and clear the reset token
        $stmt = $mysqli->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_token_expiration = NULL WHERE id = ?");
        $stmt->bind_param('si', $hashedPassword, $userId);
        $stmt->execute();

        echo json_encode(['status' => 'success', 'messages' => ['Password reset successful!']]);
    } else {
        echo json_encode(['status' => 'error', 'messages' => ['Invalid request.']]);
    }
} else {
    echo json_encode(['status' => 'error', 'messages' => ['Invalid request method.']]);
}

$mysqli->close();
