<?php
session_start();
require "config.php";

$timeout_duration = 900; // 15 minutes

// Session timeout check
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
    session_unset();
    session_destroy();
    header("Location: auth?status=session_timed_out");
    exit();
}
$_SESSION['LAST_ACTIVITY'] = time(); // Update last activity time

// Session creation and regeneration
if (!isset($_SESSION['CREATED'])) {
    $_SESSION['CREATED'] = time();
} elseif (time() - $_SESSION['CREATED'] > $timeout_duration) {
    session_regenerate_id(true);
    $_SESSION['CREATED'] = time();
}

// Restrict direct access to certain pages or files
$current_page = basename($_SERVER['PHP_SELF']);
$restricted_pages = ['sign-out'];

if (in_array($current_page, $restricted_pages)) {
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_email'])) {
        session_unset();
        session_destroy();
        header("Location: auth?status=unauthorized_access");
        exit();
    }
}

// Check if the user is logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_email'])) {
    header("Location: auth?status=user_not_logged_in");
    exit();
}

// Retrieve user details from the database
$userId = $_SESSION['user_id'];
$query = "SELECT id, full_name, email, password, support_pin, verification_code, email_verified, profile_updated, user_type, user_ip_address, browser_data, date_in, last_visit, reset_token, reset_token_expiration FROM users WHERE id = ?";
$stmt = $mysqli->prepare($query);
$stmt->bind_param('i', $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user) {
    // Validate session email
    if ($_SESSION['user_email'] !== $user['email']) {
        session_unset();
        session_destroy();
        header("Location: auth?status=session_email_mismatch");
        exit();
    }

    if ($user['user_type'] !== 'admin') {
        header("Location: auth?status=access_denied");
        session_unset();
        session_destroy();
        exit();
    }

    // Update user last visit time
    $updateQuery = "UPDATE users SET last_visit = NOW(), user_ip_address = ?, browser_data = ? WHERE id = ?";
    $updateStmt = $mysqli->prepare($updateQuery);
    $updateStmt->bind_param('ssi', $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT'], $userId);
    $updateStmt->execute();
    $updateStmt->close();
} else {
    header("Location: auth?status=user_not_found");
    session_unset();
    session_destroy();
    exit();
}
