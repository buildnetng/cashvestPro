<?php

$email = $_SESSION["user_email"];

$sql = "SELECT * FROM users WHERE email = ? LIMIT 1;";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("s", $mail);
$mail = $email;
$stmt->execute();
$user = $stmt->get_result();
$user = $user->fetch_assoc();



