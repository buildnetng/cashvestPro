<?php
require 'config.php';

$sql = "SELECT `id`, `site_title`, `meta_keywords`, `meta_desc`, `meta_author`, `theme_color`, `company_phone`, `company_email`, `company_address`, `gmail_account`, `gmail_password`, `reply_to_address`, `pagination_number`, `logo`, `favicon`, `site_url`, `account_url`, `multiple_jobs`, `same_cv`, `allow_feedback`, `mentainace_mode`, `created_at` FROM `system_setup` WHERE 1 LIMIT 1";
$result = $mysqli->query($sql);

// Initialize variables (undefined initially)
$id = $site_title = $meta_keywords = $meta_desc = $meta_author = $theme_color = $company_phone = $company_email = $company_address = $gmail_account = $gmail_password = $reply_to_address = $pagination_number = $logo = $favicon = $site_url = $account_url = $multiple_jobs = $same_cv = $allow_feedback = $mentainace_mode = $created_at = null;

// Check if result is available
if ($result && $row = $result->fetch_assoc()) {
    // Assign database values to variables
    $id = $row['id'];
    $site_title = $row['site_title'];
    $meta_keywords = $row['meta_keywords'];
    $meta_desc = $row['meta_desc'];
    $meta_author = $row['meta_author'];
    $theme_color = $row['theme_color'];
    $company_phone = $row['company_phone'];
    $company_email = $row['company_email'];
    $company_address = $row['company_address'];
    $gmail_account = $row['gmail_account'];
    $gmail_password = $row['gmail_password'];
    $reply_to_address = $row['reply_to_address'];
    $pagination_number = $row['pagination_number'];
    $logo = $row['logo']; // Full path including 'uploads/' already
    $favicon = $row['favicon']; // Full path including 'uploads/' already
    $site_url = rtrim($row['site_url'], '/') . '/';
    $account_url = $row['account_url'];
    $multiple_jobs = $row['multiple_jobs'];
    $same_cv = $row['same_cv'];
    $allow_feedback = $row['allow_feedback'];
    $mentainace_mode = $row['mentainace_mode'];
    $created_at = $row['created_at'];
}

// Define full paths using variables
$logo_path = $site_url . $logo;
$favicon_path = $site_url . $favicon;
