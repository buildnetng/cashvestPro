<?php
$host = 'localhost';
$dbname = 'mnxwvsmy_XcWz*3icCXksjCIUc1_noble_data';
$username = 'mnxwvsmy_noble045x2user_users';
$password = '&b}UGD%^VKxGM^@}r?';
// Create database connection
$mysqli = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($mysqli->connect_error) {
    error_log($mysqli->connect_error);
    die('Database connection failed.');
}
