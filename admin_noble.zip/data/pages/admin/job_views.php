<?php
include_once "data/includes/head.php";
require_once 'data/processors/config.php';

$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$limit = 9;
$offset = ($page - 1) * $limit;
$search = isset($_GET['search']) ? '%' . $mysqli->real_escape_string($_GET['search']) . '%' : '%';

// Prepare the main statement with the additional fields
$stmt = $mysqli->prepare("
    SELECT 
        id, job_title, job_location, school_name, description, 
        application_deadline, date_created, post_status, 
        experience, degree, job_type, company_name, 
        contact_email, salary_range 
    FROM jobs 
    WHERE job_title LIKE ? 
    ORDER BY date_created DESC 
    LIMIT ? OFFSET ?
");
$stmt->bind_param("sii", $search, $limit, $offset);
$stmt->execute();
$result = $stmt->get_result();

// Prepare the total count statement
$totalStmt = $mysqli->prepare("SELECT COUNT(*) AS total FROM jobs WHERE job_title LIKE ?");
$totalStmt->bind_param("s", $search);
$totalStmt->execute();
$totalResult = $totalStmt->get_result();
$totalJobs = $totalResult->fetch_assoc()['total'];
$totalPages = ceil($totalJobs / $limit);

$hasPosts = $totalJobs > 0;

// Close statements
$stmt->close();
$totalStmt->close();
?>

<body>
    <div class="wrapper">
        <?php include_once "data/includes/header.php"; ?>

        <main class="content">
            <div class="container-fluid p-0 ">

                <div class="card">
                    <div class="card-body">
                        <a href="job-add" class="btn btn-primary float-end mt-n1"><i class="fas fa-plus"></i> Add Jobs</a>

                        <!-- Search Form -->
                        <div class="col-md-4">
                            <form method="GET" class="mb-3">
                                <div class="input-group">
                                    <input type="text" class="form-control" name="search" placeholder="Search jobs" value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
                                    <button class="btn btn-primary" type="submit">Search</button>
                                </div>
                            </form>
                        </div>
                        <?php if ($hasPosts): ?>


                            <!-- Job Cards -->
                            <div class="row my-5 gy-4 job-listings grid-view">
                                <?php while ($row = $result->fetch_assoc()): ?>
                                    <div class="col-md-6 col-lg-4 m-3">
                                        <div class="card border-0 shadow-sm" style="border-radius: 20px;border: 1px solid gray;">
                                            <div class="card-body d-flex flex-column">
                                                <!-- Job Title and Company -->
                                                <div class="mb-3">
                                                    <h6 class="card-title fw-bold mb-1"><?= htmlspecialchars($row['job_title']) ?></h6>
                                                    <p class="text-muted small mb-0"><?= htmlspecialchars($row['job_location']) ?></p>
                                                </div>

                                                <div class="mb-3">
                                                    <span class="badge bg-warning-light text-warning fw-normal">Apply by <?= htmlspecialchars($row['application_deadline']) ?></span>
                                                </div>

                                                <!-- Action Buttons -->
                                                <div class="d-flex justify-content-between mt-auto">
                                                    <button class="btn btn-info btn-sm rounded-pill edit-job" data-bs-toggle="modal" data-bs-target="#editModal<?= $row['id'] ?>">Edit Post</button>
                                                    <button class="btn btn-danger btn-sm rounded-pill delete-job" data-id="<?= $row['id'] ?>">Delete Post</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Edit Job Modal -->
                                    <div class="modal fade" id="editModal<?= $row['id']; ?>" tabindex="-1" aria-labelledby="editModalLabel<?= $row['id']; ?>" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Edit Job</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body m-3">
                                                   
                                                    <form id="editJobForm<?= $row['id']; ?>">
                                                    <input type="hidden" name="id" value="<?= htmlspecialchars($row['id']) ?>">
                                                    
                                                    <div class="form-group">
                                                        <label for="editJobTitle<?= $row['id']; ?>">Job Title</label>
                                                        <input type="text" class="form-control" name="job_title" id="editJobTitle<?= $row['id']; ?>" value="<?= htmlspecialchars($row['job_title']) ?>">
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                        <label for="editJobLocation<?= $row['id']; ?>">Location</label>
                                                        <input type="text" class="form-control" name="job_location" id="editJobLocation<?= $row['id']; ?>" value="<?= htmlspecialchars($row['job_location']) ?>">
                                                    </div>
                                                
                                                    <!-- School Name -->
                                                    <div class="form-group">
                                                        <label for="editSchoolName<?= $row['id']; ?>">School Name</label>
                                                        <input type="text" class="form-control" name="school_name" id="editSchoolName<?= $row['id']; ?>" value="<?= htmlspecialchars($row['school_name']) ?>">
                                                    </div>
                                                
                                                    <!-- Salary Range -->
                                                    <div class="form-group">
                                                        <label for="editSalaryRange<?= $row['id']; ?>">Salary Range</label>
                                                        <input type="text" class="form-control" name="salary_range" id="editSalaryRange<?= $row['id']; ?>" value="<?= htmlspecialchars($row['salary_range']) ?>">
                                                    </div>
                                                
                                                    <!-- Experience -->
                                                    <div class="form-group">
                                                        <label for="editExperience<?= $row['id']; ?>">Experience</label>
                                                        <input type="text" class="form-control" name="experience" id="editExperience<?= $row['id']; ?>" value="<?= htmlspecialchars($row['experience']) ?>">
                                                    </div>
                                                
                                                    <!-- Degree -->
                                                    <div class="form-group">
                                                        <label for="editDegree<?= $row['id']; ?>">Degree</label>
                                                        <input type="text" class="form-control" name="degree" id="editDegree<?= $row['id']; ?>" value="<?= htmlspecialchars($row['degree']) ?>">
                                                    </div>
                                                
                                                    <!-- Job Type -->
                                                    <div class="form-group">
                                                        <label for="editJobType<?= $row['id']; ?>">Job Type</label>
                                                        <input type="text" class="form-control" name="job_type" id="editJobType<?= $row['id']; ?>" value="<?= htmlspecialchars($row['job_type']) ?>">
                                                    </div>
                                                
                                                    <!-- Company Name -->
                                                    <div class="form-group">
                                                        <label for="editCompanyName<?= $row['id']; ?>">Company Name</label>
                                                        <input type="text" class="form-control" name="company_name" id="editCompanyName<?= $row['id']; ?>" value="<?= htmlspecialchars($row['company_name']) ?>">
                                                    </div>
                                                
                                                    <!-- Contact Email -->
                                                    <div class="form-group">
                                                        <label for="editContactEmail<?= $row['id']; ?>">Contact Email</label>
                                                        <input type="email" class="form-control" name="contact_email" id="editContactEmail<?= $row['id']; ?>" value="<?= htmlspecialchars($row['contact_email']) ?>">
                                                    </div>
                                                
                                                    <div class="form-group mb-3">
                                                        <label for="editDescription<?= $row['id']; ?>">Job Description</label>
                                                        <div id="editDescription<?= $row['id']; ?>" class="quill-editor"></div>
                                                        <input type="hidden" name="description" id="descriptionInput<?= $row['id']; ?>" value="<?= htmlspecialchars($row['description']) ?>">
                                                    </div>
                                                
                                                    <div class="form-group">
                                                        <label for="editApplicationDeadline<?= $row['id']; ?>">Application Deadline</label>
                                                        <input type="date" class="form-control" name="application_deadline" id="editApplicationDeadline<?= $row['id']; ?>" value="<?= htmlspecialchars($row['application_deadline']) ?>">
                                                    </div>
                                                
                                                    <div class="modal-footer">
                                                        <button class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                                                        <button class="btn btn-primary save-job-changes" type="button" data-id="<?= $row['id']; ?>">Save Changes</button>
                                                    </div>
                                                </form>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            </div>

                            <!-- Pagination Controls -->
                            <div class="col-md-4">
                                <nav aria-label="Page navigation">
                                    <ul class="pagination justify-content-start">
                                        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                                            <a class="page-link" href="?search=<?= urlencode($_GET['search'] ?? '') ?>&page=<?= $page - 1 ?>" aria-label="Previous">
                                                <span aria-hidden="true">&laquo;</span>
                                            </a>
                                        </li>
                                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                            <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                                <a class="page-link" href="?search=<?= urlencode($_GET['search'] ?? '') ?>&page=<?= $i ?>"><?= $i ?></a>
                                            </li>
                                        <?php endfor; ?>
                                        <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
                                            <a class="page-link" href="?search=<?= urlencode($_GET['search'] ?? '') ?>&page=<?= $page + 1 ?>" aria-label="Next">
                                                <span aria-hidden="true">&raquo;</span>
                                            </a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        <?php else: ?>
                            <!-- No Posts Found Message -->
                            <p class="">No jobs available at the moment.</p>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </main>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>
        <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">

        <script>
            $(document).ready(function() {
                var quillEditors = {};

                $('.quill-editor').each(function() {
                    var editorId = $(this).attr('id');
                    var hiddenInputId = '#descriptionInput' + editorId.replace('editDescription', '');
                    var initialContent = $(hiddenInputId).val();

                    quillEditors[editorId] = new Quill('#' + editorId, {
                        theme: 'snow',
                        modules: {
                            toolbar: [
                                [{
                                    header: [1, 2, false]
                                }],
                                ['bold', 'italic', 'underline'],
                                ['link', 'blockquote', 'code-block'],
                                [{
                                    list: 'ordered'
                                }, {
                                    list: 'bullet'
                                }]
                            ]
                        }
                    });

                    // Inject the content from the hidden input field into the Quill editor
                    if (initialContent) {
                        quillEditors[editorId].clipboard.dangerouslyPasteHTML(initialContent);
                    }
                });

                // Handle form submission
                $('.save-job-changes').on('click', function(e) {
                    e.preventDefault();
                    var jobId = $(this).data('id');
                    var formId = '#editJobForm' + jobId;

                    // Update hidden input with Quill editor content
                    var editorId = 'editDescription' + jobId;
                    var quillEditor = quillEditors[editorId];
                    $('#descriptionInput' + jobId).val(quillEditor.root.innerHTML);

                    $.ajax({
                        url: 'data/processors/forms/process_update_job.php',
                        type: 'POST',
                        data: $(formId).serialize(),
                        dataType: 'json',
                        success: function(response) {
                            if (response.status === 'success') {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Success!',
                                    text: response.messages.join('\n')
                                }).then(() => {
                                    location.reload();
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Error!',
                                    text: response.messages.join('\n')
                                });
                            }
                        },
                        error: function() {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error!',
                                text: 'An error occurred while updating the job.'
                            });
                        }
                    });
                });


                $(document).on('click', '.delete-job', function() {
                    var jobId = $(this).data('id');

                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            // Disable the button to prevent multiple clicks
                            $(this).prop('disabled', true);

                            $.ajax({
                                url: 'data/processors/forms/process_delete_job.php',
                                type: 'POST',
                                data: {
                                    id: jobId
                                },
                                dataType: 'json',
                                success: function(response) {
                                    if (response.status === 'success') {
                                        Swal.fire('Deleted!', 'Your job has been deleted.', 'success').then(function() {
                                            location.reload();
                                        });
                                    } else {
                                        Swal.fire('Error', response.messages.join('<br>'), 'error');
                                    }
                                },
                                error: function(xhr, status, error) {
                                    Swal.fire('Error', 'An error occurred while deleting the job: ' + error, 'error');
                                    console.error('AJAX Error:', xhr, status, error); // Log detailed error info
                                },
                                complete: function() {
                                    // Re-enable the button after AJAX completes
                                    $(this).prop('disabled', false);
                                }
                            });
                        }
                    });
                });

            });
        </script>
    </div>
</body>