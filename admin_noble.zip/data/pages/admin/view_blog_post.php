<?php include_once "data/includes/head.php"; ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/css/lightbox.min.css">

<!-- DataTables CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">


<body>
    <div class="wrapper">
        <?php include_once "data/includes/header.php"; ?>


        <main class="content">
            <div class="container-fluid p-0">

                <h1 class="h3 mb-3">View Blog Post</h1>

                <?php
                require_once 'data/processors/config.php';

                // Fetch blog posts
                $sql = "SELECT id, blog_title, description, image_path, date_created FROM blog_posts";
                $result = $mysqli->query($sql);
                ?>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <!-- Optional: Add any card header content here -->
                            </div>

                            <div class="card-body">
                                <table id="datatables-responsive" class="table table-striped w-100">
                                    <thead>
                                        <tr>
                                            <th>Post Image</th>
                                            <th>Post Title</th>
                                            <th>Date In</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($row = $result->fetch_assoc()): ?>
                                            <?php
                                            $id = htmlspecialchars($row['id']);
                                            $blog_title = htmlspecialchars($row['blog_title']);
                                            $description = htmlspecialchars($row['description']);
                                            $image_path = htmlspecialchars($row['image_path']);
                                            $date_created = date('Y-m-d', strtotime($row['date_created']));
                                            ?>
                                            <tr>
                                                <td><a href="../<?php echo $image_path; ?>" data-lightbox="blog-image"><img src="../../<?php echo $image_path; ?>" alt="<?php echo $blog_title; ?>" style="width:100px; height:auto;"></a></td>
                                                <td><?php echo $blog_title; ?></td>
                                                <td><?php echo $date_created; ?></td>
                                            

                                                <td class="text-end">
                                                    <div class="dropdown">
                                                        <button class="btn btn-light dropdown-toggle" type="button" id="dropdownMenuButton-<?= $row['id']; ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                                            Actions
                                                        </button>
                                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton-<?= $row['id']; ?>">
                                                            <li><button type="button" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#editModal<?php echo $id; ?>">Edit Details</button></li>
                                                            <li> <button class='dropdown-item text-danger' onclick='deletePost(<?php echo $id; ?>)'>
                                                                    Delete
                                                           
                                                        </ul>
                                                    </div>
                                                </td>
                                            </tr>

                                            <!-- Modal for editing the blog post -->
                                            <div class="modal fade" id="editModal<?php echo $id; ?>" tabindex="-1" aria-labelledby="editModalLabel<?php echo $id; ?>" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="editModalLabel<?php echo $id; ?>">Edit Blog Post</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form id="editForm<?php echo $id; ?>" enctype="multipart/form-data">
                                                                <input type="hidden" id="postId<?php echo $id; ?>" name="id" value="<?php echo $id; ?>">
                                                                <div class="mb-3">
                                                                    <label for="editTitle<?php echo $id; ?>" class="form-label">Title</label>
                                                                    <input type="text" class="form-control" id="editTitle<?php echo $id; ?>" name="title" value="<?php echo $blog_title; ?>" required>
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="editDescription<?php echo $id; ?>" class="form-label">Description</label>
                                                                    <div id="editDescription<?php echo $id; ?>" class="quill-editor" style="height: 200px;"><?php echo $description; ?></div>
                                                                    <input type="hidden" id="descriptionInput<?php echo $id; ?>" name="description" value="<?php echo $description; ?>">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="editImage<?php echo $id; ?>" class="form-label">Image</label>
                                                                    <input type="file" class="form-control" id="editImage<?php echo $id; ?>" name="image">
                                                                    <input type="hidden" id="currentImage<?php echo $id; ?>" name="currentImage" value="<?php echo $image_path; ?>">
                                                                </div>
                                                                <button type="submit" class="btn btn-primary">Save changes</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Include jQuery and Quill libraries if not already included -->
                <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                <script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
                <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">

                <script>
                    $(document).ready(function() {
                        var quillEditors = {};

                        // Initialize Quill editors for each modal
                        $('.quill-editor').each(function() {
                            var editorId = $(this).attr('id');
                            var hiddenInputId = '#descriptionInput' + editorId.replace('editDescription', '');
                            var initialContent = $(hiddenInputId).val();

                            quillEditors[editorId] = new Quill('#' + editorId, {
                                theme: 'snow',
                                modules: {
                                    toolbar: [
                                        [{
                                            header: [1, 2, false]
                                        }],
                                        ['bold', 'italic', 'underline'],
                                        ['link', 'blockquote', 'code-block'],
                                        [{
                                            list: 'ordered'
                                        }, {
                                            list: 'bullet'
                                        }]
                                    ]
                                }
                            });

                            // Inject the content from the hidden input field into the Quill editor
                            if (initialContent) {
                                quillEditors[editorId].clipboard.dangerouslyPasteHTML(initialContent);
                            }
                        });

                        // Handle form submission via AJAX
                        $('form').on('submit', function(e) {
                            e.preventDefault();

                            var form = $(this);
                            var formId = form.attr('id');
                            var idMatch = formId.match(/(\d+)$/);

                            if (!idMatch) {
                                console.error('Form ID does not have a valid format.');
                                return;
                            }

                            var uniqueId = idMatch[1];
                            var editorId = 'editDescription' + uniqueId;
                            var quillEditor = quillEditors[editorId];
                            var descriptionInput = $('#descriptionInput' + uniqueId);

                            if (!quillEditor || !descriptionInput.length) {
                                console.error('Quill editor or description input not found.');
                                return;
                            }

                            // Update hidden input with Quill editor content
                            descriptionInput.val(quillEditor.root.innerHTML);

                            $.ajax({
                                url: 'data/processors/forms/update_blog_post.php',
                                type: 'POST',
                                data: new FormData(this), // Serialize the entire form
                                contentType: false,
                                processData: false,
                                dataType: 'json',
                                success: function(response) {
                                    if (response.status === 'success') {
                                        Swal.fire({
                                            icon: 'success',
                                            title: 'Success!',
                                            text: response.message
                                        }).then(() => {
                                            location.reload(); // Reload the page to see the changes
                                        });
                                    } else {
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Error!',
                                            text: response.message
                                        });
                                    }
                                },
                                error: function() {
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Error!',
                                        text: 'An error occurred while updating the post.'
                                    });
                                }
                            });
                        });
                    });
                </script>

            </div>
        </main>
        <script src="assets/js/app.js"></script>
        <?php include_once "includes/footer.php"; ?>


        <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>

        <!-- DataTables JS -->
        <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
        <script>
            $(document).ready(function() {
                $('#datatables-responsive').DataTable({
                    "paging": true, // Enable pagination
                    "searching": true, // Enable search functionality
                    "ordering": true, // Enable column ordering
                    "lengthMenu": [5, 10, 25, 50, 100], // Set page length options
                    "pageLength": 10, // Set default page length
                    "columnDefs": [{
                            "orderable": false,
                            "targets": 4
                        } // Disable ordering on the 'Action' column
                    ]
                });
            });
        </script>

        <script>
            function deletePost(id) {
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to recover this post!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: 'data/processors/forms/delete_blog_post.php',
                            method: 'GET', // Changed from POST to GET
                            data: {
                                id: id
                            },
                            success: function(response) {
                                if (response.status === 'success') {
                                    Swal.fire(
                                        'Deleted!',
                                        'Post has been deleted.',
                                        'success'
                                    ).then(() => {
                                        location.reload(); // Reload to update the table
                                    });
                                } else {
                                    Swal.fire(
                                        'Error!',
                                        'Failed to delete post: ' + response.message,
                                        'error'
                                    );
                                }
                            },
                            error: function() {
                                Swal.fire(
                                    'Error!',
                                    'An error occurred while processing your request.',
                                    'error'
                                );
                            }
                        });
                    }
                });
            }
        </script>

</body>

</html>