<?php
include_once "data/includes/head.php";
include_once "data/includes/config.php";
$queries = [
	"jobs" => "SELECT COUNT(*) AS count FROM jobs",
	"jobs" => "SELECT COUNT(*) AS count FROM jobs",
	"job_applications" => "SELECT COUNT(*) AS count FROM job_applications",
	"enquiries" => "SELECT COUNT(*) AS count FROM contact_messages",
	"subscribers" => "SELECT COUNT(*) AS count FROM subscribers",
	
	"reviews" => "SELECT COUNT(*) AS count FROM user_reviews",
	"comments" => "SELECT COUNT(*) AS count FROM job_comments",
	"noble_teachers" => "SELECT COUNT(*) AS count FROM noble_teachers",
	"blog_posts" => "SELECT COUNT(*) AS count FROM blog_posts",
	
];

$data = [];
foreach ($queries as $key => $query) {
	$result = $mysqli->query($query); // Execute query
	if ($result) {
		$data[$key] = $result->fetch_assoc()['count'];
		$result->free(); // Free result set
	} else {
		$data[$key] = 0; // Default value if query fails
	}
}
?>

<body>
	<div class="wrapper">
		<?php include_once "data/includes/header.php"; ?>

		<main class="content">
			<div class="container-fluid p-0">
				<h1 class="h3 mb-3">Welcome <?= htmlspecialchars($user["full_name"]); ?></h1>

				<div class="row">
					<?php
					$cards = [
						['Available Jobs', $data['jobs']],
						['Applications', $data['job_applications']],
						['Enquiries', $data['enquiries']],
						['Newsletter Subscribers', $data['subscribers']],
						['Total Reviews', $data['reviews']],
						['Comments', $data['comments']],
						['Noble Teachers', $data['noble_teaches']],
						['Blog Post', $data['blog_posts']],
					];
					
					foreach ($cards as $card) {
						echo '<div class="col-6 col-sm-3 col-xxl-3 d-flex">
                                <div class="card flex-fill">
                                    <div class="card-body py-4">
                                        <div class="d-flex align-items-start">
                                            <div class="flex-grow-1">
                                                <h3 class="mb-2">' . htmlspecialchars($card[1]) . '</h3>
                                                <p class="mb-2">' . htmlspecialchars($card[0]) . '</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>';
					}
					?>
				</div>
			</div>
		</main>

		<script src="assets/js/app.js"></script>

		<?php include_once "data/includes/footer.php"; ?>
	</div>
</body>

</html>