<?php include_once "data/includes/head.php"; ?>

<body>
	<div class="wrapper">
		<?php include_once "data/includes/header.php"; ?>

		<main class="content">
			<div class="container-fluid p-0">

				<div class="row mb-2 mb-xl-3">
					<div class="col-auto d-none d-sm-block">
						<h3>Account</h3>
					</div>

				</div>
				<div class="row">
					<div class="col-lg-6 col-xl-5 d-flex">
						<div class="w-100">

							<div class="row">
								<div class="col-sm-6 col-lg-12 col-xxl-12 d-flex">
									<div class="card illustration flex-fill">
										<div class="card-body p-0 d-flex flex-fill">
											<div class="row g-0 w-100">
												<div class="col-6">
													<div class="illustration-text p-3 m-1">
														<h4 class="illustration-text">Welcome Back, Chris!</h4>
														<p class="mb-0">User Dashboard</p>
													</div>
												</div>
												<div class="col-6 align-self-end text-end">
													<img src="img/illustrations/searching.png" alt="Searching"
														class="img-fluid illustration-img">
												</div>
											</div>
										</div>
									</div>
								</div>

								<!-- <div class="col-sm-6 col-lg-12 col-xxl-12 d-flex">
									<div class="card flex-fill">
										<div class="text-center">
											<div class="mt-2 ">
												<img class="img-thumbnail rounded-circle avatar-xl" alt="200x200"
													src="https://themesdesign.in/stexo/layouts/assets/images/users/user-4.jpg"
													data-holder-rendered="true">
												<p>Date Registered: <span class="fw-bold">20/2/2024</span></p>
												<span class="badge badge-subtle-success">Application Approved</span>
											</div>
										</div>
										<div class="card-body">
											<table class="table table-striped">
												<thead>

												</thead>
												<tbody>
													<tr>
														<td>ID</td>
														<td>#96896</td>

													</tr>
													<tr>
														<td>Name</td>
														<td>Ashley Briggs</td>

													</tr>
													<tr>
														<td>Phone No.</td>
														<td>914-939-2458</td>

													</tr>
													<tr>
														<td>Email</td>
														<td>samuel@gmail.com</td>

													</tr>

												</tbody>
											</table>
										</div>
									</div>
								</div> -->
							</div>


						</div>
					</div>

					<div class="col-lg-6 col-xl-7">
						<div class="card flex-fill">
							<div class="card-body py-4">
								<div class="d-flex align-items-start">
									<div class="flex-grow-1">
										<h3 class="mb-2">10</h3>
										<p class="mb-2">Job Applications</p>

									</div>
									<div class="d-inline-block ms-3">
										<div class="stat">
											<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" data-lucide="shopping-bag" class="lucide lucide-shopping-bag align-middle text-danger">
												<path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"></path>
												<path d="M3 6h18"></path>
												<path d="M16 10a4 4 0 0 1-8 0"></path>
											</svg>
										</div>
									</div>
								</div>
							</div>
						</div>


					</div>
				</div>



			</div>
		</main>

		<?php include_once "includes/footer.php"; ?>

</body>
</html>