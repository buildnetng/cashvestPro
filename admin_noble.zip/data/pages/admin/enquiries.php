<?php include_once "data/includes/head.php"; ?>

<body>
    <div class="wrapper">
        <?php include_once "data/includes/header.php"; ?>

        <main class="content">
            <div class="container-fluid p-0">
                <div class="row mb-3">
                    <!-- Search Form -->
                    <div class="col-md-6">
                        <form method="get" action="">
                            <div class="input-group">
                                <input type="text" class="form-control" name="search" placeholder="Search by name or reason" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                                <button class="btn btn-primary" type="submit">Search</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <?php
                    // Pagination and search handling
                    $limit = 5;
                    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page number
                    $start = ($page - 1) * $limit;

                    // Search query
                    $searchTerm = isset($_GET['search']) ? $_GET['search'] : '';
                    $searchQuery = !empty($searchTerm) ? "WHERE first_name LIKE '%$searchTerm%' OR last_name LIKE '%$searchTerm%' OR reason LIKE '%$searchTerm%'" : '';

                    // Fetch contact messages from the database with pagination
                    $query = "SELECT id, first_name, last_name, reason, message, created_at FROM contact_messages $searchQuery LIMIT $start, $limit";
                    $result = $mysqli->query($query);

                    if (!$result) {
                        die('Error: ' . $mysqli->error); // Handle query error
                    }

                    // Loop through each row and display the contact message data in a card
                    while ($row = $result->fetch_assoc()): ?>
                        <div class="col-md-4 mb-3">
                            <div class="card">
                                <div class="card-header">
                                    <h5><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></h5>
                                </div>
                                <div class="card-body">
                                    <p><strong>Reason:</strong> <?php echo htmlspecialchars($row['reason']); ?></p>
                                    <p><strong>Date:</strong> <?php echo htmlspecialchars($row['created_at']); ?></p>
                                    <p><strong>Message:</strong><br> <?php echo nl2br(htmlspecialchars($row['message'])); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endwhile;

                    // Pagination - Get total records count and calculate total pages
                    $countQuery = "SELECT COUNT(*) AS total FROM contact_messages $searchQuery";
                    $countResult = $mysqli->query($countQuery);
                    $total = $countResult->fetch_assoc()['total'];
                    $totalPages = ceil($total / $limit);
                    ?>

                </div>

                <!-- Debug: Output the total number of pages -->
                <p>Total Pages: <?php echo $totalPages; ?></p>

                <!-- Pagination Links -->
                <?php if ($totalPages > 1): ?>
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-center">
                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=1<?php echo !empty($searchTerm) ? '&search=' . urlencode($searchTerm) : ''; ?>">First</a>
                            </li>
                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page - 1; ?><?php echo !empty($searchTerm) ? '&search=' . urlencode($searchTerm) : ''; ?>">Previous</a>
                            </li>
                            <li class="page-item <?php echo $page >= $totalPages ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $page + 1; ?><?php echo !empty($searchTerm) ? '&search=' . urlencode($searchTerm) : ''; ?>">Next</a>
                            </li>
                            <li class="page-item <?php echo $page >= $totalPages ? 'disabled' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $totalPages; ?><?php echo !empty($searchTerm) ? '&search=' . urlencode($searchTerm) : ''; ?>">Last</a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>

</html>
