<?php include_once "data/includes/head.php"; ?>

<body>
    <div class="wrapper">
        <?php include_once "data/includes/header.php"; ?>


        <main class="content">
            <div class="container-fluid p-0">

                <h1 class="h3 mb-3">Newsletter Subscribers</h1>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">

                            </div>
                            <div class="card-body">
                                <table id="datatables-reponsive" class="table table-striped w-100">
                                    <thead>
                                        <tr>
                                            <th>ID</th> <!-- Adjusted header to reflect actual column -->
                                            <th>Email Address</th>
                                            <th>Date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        require_once 'data/processors/config.php'; 

                                        $query = "SELECT `id`, `user_email`, `subscribed_at` FROM `subscribers` WHERE 1";
                                        $result = $mysqli->query($query); 

                                        while ($row = $result->fetch_assoc()) {
                                            $id = $row['id'];
                                            $email = $row['user_email'];
                                            $formattedDate = date('d/m/Y', strtotime($row['subscribed_at'])) ?: 'N/A'; // Format the date

                                            echo "<tr>";
                                            echo "<td>" . htmlspecialchars($id) . "</td>"; // Display ID
                                            echo "<td>" . htmlspecialchars($email) . "</td>"; // Display Email
                                            echo "<td>" . htmlspecialchars($formattedDate) . "</td>"; // Display Formatted Date
                                            echo "<td><button class='btn mb-2 btn-danger' onclick='deleteSubscriber($id)'>Delete <i class='fas fa-times'></i></button></td>"; // Action Button
                                            echo "</tr>";
                                        }

                                        $result->free(); // Free result set
                                        $mysqli->close(); // Close connection
                                        ?>
                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>



            </div>
        </main>
        <script src="js/app.js"></script>

        <script>
            document.addEventListener("DOMContentLoaded", function() {
                // Datatables Responsive
                $("#datatables-reponsive").DataTable({
                    destroy: true,
                    responsive: true
                });
            });
        </script>
        <?php include_once "includes/footer.php"; ?>

        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- Include SweetAlert2 -->
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> <!-- Include jQuery -->

        <script>
            function deleteSubscriber(id) {
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            url: 'data/processors/forms/delete_subscriber.php',
                            type: 'POST',
                            data: {
                                id: id
                            },
                            dataType: 'json',
                            success: function(response) {
                                if (response.status === 'success') {
                                    Swal.fire(
                                        'Deleted!',
                                        response.message,
                                        'success'
                                    ).then(() => {
                                        // Remove the row from the table
                                        document.querySelector(`button[onclick="deleteSubscriber(${id})"]`).closest('tr').remove();
                                    });
                                } else {
                                    Swal.fire(
                                        'Error!',
                                        response.message,
                                        'error'
                                    );
                                }
                            },
                            error: function() {
                                Swal.fire(
                                    'Error!',
                                    'An error occurred while deleting the subscriber. Please try again.',
                                    'error'
                                );
                            }
                        });
                    }
                });
            }
        </script>

</body>

</html>