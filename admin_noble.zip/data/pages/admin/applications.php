<?php
include_once "data/includes/head.php";
require_once 'data/processors/config.php';

?>

<body>
	<div class="wrapper">
		<?php include_once "data/includes/header.php"; ?>

		<main class="content">
			<div class="container-fluid p-0">
				<div class="card">
					<div class="card-body">
						<div class="row">
							<!-- Any additional content for the row -->
						</div>
						<?php

						$items_per_page = 10;
						$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
						$offset = ($current_page - 1) * $items_per_page;

						// Search filter
						$search_name = isset($_GET['name']) ? $mysqli->real_escape_string($_GET['name']) : '';
						$search_email = isset($_GET['email']) ? $mysqli->real_escape_string($_GET['email']) : '';

						// Build query with search filters and pagination
						$query = "SELECT 
            `id`, `user_id`, `job_id`, `name`, `email`, `phone`, `location`, 
            `resume`, `cover_letter`, `additional_info`, `country`, `state`, 
            `city`, `zipcode`, `status`, `job_title`, `job_location`, 
            `school_name`, `description`, `application_deadline`, `posted_time`, 
            `post_status`, `date_created`, `experience`, `degree`, 
            `job_type`, `company_name`, `contact_email`, `salary_range`
          FROM `job_applications` 
          WHERE `name` LIKE '%$search_name%' 
          AND `email` LIKE '%$search_email%' 
          LIMIT $offset, $items_per_page";

						$result = $mysqli->query($query);

						// Check for errors
						if (!$result) {
							die("Database query failed: " . $mysqli->error);
						}

						// Count total records for pagination
						$total_query = "SELECT COUNT(*) as total 
                FROM `job_applications` 
                WHERE `name` LIKE '%$search_name%' 
                AND `email` LIKE '%$search_email%'";
						$total_result = $mysqli->query($total_query);
						$total_row = $total_result->fetch_assoc();
						$total_items = $total_row['total'];
						$total_pages = ceil($total_items / $items_per_page);

						$public_url = "http://localhost/nobble/";
						?>

						<!-- Search Form -->
						<form method="GET" action="">
							<div class="row">
								<div class="col-md-4">
									<input type="text" name="name" class="form-control" placeholder="Search by Name" value="<?= htmlspecialchars($search_name); ?>">
								</div>
								<div class="col-md-4">
									<input type="text" name="email" class="form-control" placeholder="Search by Email" value="<?= htmlspecialchars($search_email); ?>">
								</div>
								<div class="col-md-4">
									<button type="submit" class="btn btn-primary">Search</button>
								</div>
							</div>
						</form>
						<table class="table w-100">
							<thead>
								<tr>
									<th class="align-middle w-25px">
										<div class="form-check fs-4">
											<input class="form-check-input tasks-check-all" type="checkbox" id="tasks-check-all">
											<label class="form-check-label" for="tasks-check-all"></label>
										</div>
									</th>
									<th>Name</th>
									<th>Email</th>
									<th>Due Date</th>
									<th>Status</th>
									<th>Actions</th>
								</tr>
							</thead>
							<tbody>
								<?php while ($row = $result->fetch_assoc()): ?>
									<tr id="application-row-<?= $row['id']; ?>">
										<td>
											<div class="form-check fs-4">
												<input class="form-check-input" type="checkbox" id="checkbox-<?= $row['id']; ?>">
												<label class="form-check-label" for="checkbox-<?= $row['id']; ?>"></label>
											</div>
										</td>
										<td><?= htmlspecialchars($row['name']); ?></td>
										<td><?= htmlspecialchars($row['email']); ?></td>
										<td><?= htmlspecialchars(date('F j, Y', strtotime($row['date_created']))); ?></td>
										<td>
											<span class="badge rounded-pill bg-<?= $row['status'] == 'Approved' ? 'success' : ($row['status'] == 'Rejected' ? 'danger' : 'warning text-dark'); ?>">
												<?= htmlspecialchars($row['status']); ?>
											</span>
										</td>
										<td class="text-end">
											<div class="dropdown">
												<button class="btn btn-light dropdown-toggle" type="button" id="dropdownMenuButton-<?= $row['id']; ?>" data-bs-toggle="dropdown" aria-expanded="false">
													Actions
												</button>
												<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton-<?= $row['id']; ?>">
													<li><button type="button" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#viewModal<?= $row['id']; ?>">View Details</button></li>
													<li><a class="dropdown-item text-danger btn-delete" href="#" data-id="<?= $row['id']; ?>">Delete</a></li>
													<li><a class="dropdown-item text-success btn-approve" href="#" data-id="<?= $row['id']; ?>">Approve</a></li>
													<li><a class="dropdown-item text-warning btn-reject" href="#" data-id="<?= $row['id']; ?>">Reject</a></li>
												</ul>
											</div>
										</td>
									</tr>
									<!-- Modal HTML -->
									<!-- Modal HTML -->
									<div class="modal fade" id="viewModal<?= $row['id']; ?>" tabindex="-1" aria-labelledby="viewModalLabel<?= $row['id']; ?>" aria-hidden="true">
										<div class="modal-dialog modal-lg">
											<div class="modal-content">
												<div class="modal-header">
													<h5 class="modal-title" id="viewModalLabel<?= $row['id']; ?>">Applicant Details</h5>
													<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
												</div>
												<div class="modal-body">
													<!-- User Info Section -->
													<h6><strong>User Info</strong></h6>
													<div class="row">
														<div class="col-md-6">
															<p><strong>Name:</strong> <?= htmlspecialchars($row['name']); ?></p>
															<p><strong>Email:</strong> <?= htmlspecialchars($row['email']); ?></p>
															<p><strong>Phone:</strong> <?= htmlspecialchars($row['phone']); ?></p>
															<p><strong>Location:</strong> <?= htmlspecialchars($row['location']); ?></p>
															<p><strong>Country:</strong> <?= htmlspecialchars($row['country']); ?></p>
														</div>
														<div class="col-md-6">
															<p><strong>State:</strong> <?= htmlspecialchars($row['state']); ?></p>
															<p><strong>City:</strong> <?= htmlspecialchars($row['city']); ?></p>
															<p><strong>Zipcode:</strong> <?= htmlspecialchars($row['zipcode']); ?></p>
															<p><strong>Status:</strong> <?= htmlspecialchars($row['status']); ?></p>
															<p><strong>Additional Info:</strong> <?= htmlspecialchars($row['additional_info']); ?></p>
														</div>
													</div>
													<hr>

													<!-- Job Info Section -->
													<h6><strong>Job Info</strong></h6>
													<div class="row">
														<div class="col-md-6">
															<p><strong>Job Title:</strong> <?= htmlspecialchars($row['job_title']); ?></p>
															<p><strong>Job Location:</strong> <?= htmlspecialchars($row['job_location']); ?></p>
															<p><strong>School Name:</strong> <?= htmlspecialchars($row['school_name']); ?></p>
															<p><strong>Description:</strong> <?= htmlspecialchars($row['description']); ?></p>
														</div>
														<div class="col-md-6">
															<p><strong>Experience:</strong> <?= htmlspecialchars($row['experience']); ?></p>
															<p><strong>Degree:</strong> <?= htmlspecialchars($row['degree']); ?></p>
															<p><strong>Job Type:</strong> <?= htmlspecialchars($row['job_type']); ?></p>
															<p><strong>Company Name:</strong> <?= htmlspecialchars($row['company_name']); ?></p>
															<p><strong>Salary Range:</strong> <?= htmlspecialchars($row['salary_range']); ?></p>
														</div>
													</div>
													<hr>

													<!-- Dates Section -->
													<h6><strong>Dates</strong></h6>
													<div class="row">
														<div class="col-md-6">
															<p><strong>Application Deadline:</strong> <?= htmlspecialchars($row['application_deadline']); ?></p>
															<p><strong>Posted Time:</strong> <?= htmlspecialchars($row['posted_time']); ?></p>
														</div>
														<div class="col-md-6">

															<p><strong>Date Applied:</strong> <?= htmlspecialchars($row['date_created']); ?></p>
														</div>
													</div>
													<hr>

													<!-- Downloads Section -->
													<h6><strong>Downloads</strong></h6>
													<div class="row">
														<div class="col-md-6">
															<p><strong>Resume:</strong></p>
															<a href="<?= $public_url . $row['resume']; ?>" class="btn btn-info" download>
																Download Resume
															</a>
														</div>
														<div class="col-md-6">
															<p><strong>Cover Letter:</strong></p>
															<a href="<?= $public_url . $row['cover_letter']; ?>" class="btn btn-info" download>
																Download Cover Letter
															</a>
														</div>
													</div>
												</div>
												<div class="modal-footer">
													<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
												</div>
											</div>
										</div>
									</div>

								<?php endwhile; ?>
							</tbody>
						</table>

						<!-- Pagination Controls -->
						<nav aria-label="Page navigation">
							<ul class="pagination">
								<?php if ($current_page > 1): ?>
									<li class="page-item"><a class="page-link" href="?page=<?= $current_page - 1; ?>&name=<?= htmlspecialchars($search_name); ?>&email=<?= htmlspecialchars($search_email); ?>">Previous</a></li>
								<?php endif; ?>
								<?php for ($i = 1; $i <= $total_pages; $i++): ?>
									<li class="page-item <?= $i == $current_page ? 'active' : ''; ?>"><a class="page-link" href="?page=<?= $i; ?>&name=<?= htmlspecialchars($search_name); ?>&email=<?= htmlspecialchars($search_email); ?>"><?= $i; ?></a></li>
								<?php endfor; ?>
								<?php if ($current_page < $total_pages): ?>
									<li class="page-item"><a class="page-link" href="?page=<?= $current_page + 1; ?>&name=<?= htmlspecialchars($search_name); ?>&email=<?= htmlspecialchars($search_email); ?>">Next</a></li>
								<?php endif; ?>
							</ul>
						</nav>
					</div>
				</div>
			</div>
		</main>

		<!-- Rejection Reason Modal -->
		<div class="modal fade" id="rejectionReasonModal" tabindex="-1" aria-labelledby="rejectionReasonModalLabel" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="rejectionReasonModalLabel">Reason for Rejection</h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					</div>
					<div class="modal-body">
						<form id="rejectionForm">
							<div class="mb-3">
								<label for="reason" class="form-label">Please provide a reason for rejecting this application:</label>
								<textarea class="form-control" id="reason" rows="20" required>
									Dear Micheal Bloomsbury,

Thank you for applying for the position of a Mathematics Teacher through Noble Teachers. After reviewing your application, we found that your experience does not fully align with the requirements for this role.

We appreciate your interest and encourage you to apply for positions that better match your background and qualifications.

Thank you for your understanding.

Best regards,  
Noble Teachers</textarea>
							</div>
							<input type="hidden" id="applicationIdForRejection">
						</form>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
						<button type="button" class="btn btn-primary" id="confirmRejectionBtn">Submit Reason and Reject</button>
					</div>
				</div>
			</div>
		</div>


		<script src="assets/js/app.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

		<script>
			document.addEventListener('DOMContentLoaded', function() {
				// Approve button click handler
				document.querySelectorAll('.btn-approve').forEach(function(button) {
					button.addEventListener('click', function(e) {
						e.preventDefault();
						let id = this.dataset.id;
						handleApplicationAction(id, 'approve');
					});
				});

				// Reject button click handler
				document.querySelectorAll('.btn-reject').forEach(function(button) {
					button.addEventListener('click', function(e) {
						e.preventDefault();
						let id = this.dataset.id;
						document.getElementById('applicationIdForRejection').value = id;
						$('#rejectionReasonModal').modal('show');
					});
				});

				// Handle rejection reason submission
				document.getElementById('confirmRejectionBtn').addEventListener('click', function() {
					let id = document.getElementById('applicationIdForRejection').value;
					let reason = document.getElementById('reason').value.trim();

					if (reason) {
						$('#rejectionReasonModal').modal('hide');
						handleApplicationAction(id, 'reject', reason);
					} else {
						Swal.fire('Error', 'Please provide a reason for rejection.', 'error');
					}
				});

				// Delete button click handler
				document.querySelectorAll('.btn-delete').forEach(function(button) {
					button.addEventListener('click', function(e) {
						e.preventDefault();
						let id = this.dataset.id;
						handleApplicationAction(id, 'delete');
					});
				});

				// Function to handle application actions
				function handleApplicationAction(id, action, reason = '') {
					let actionText = action.charAt(0).toUpperCase() + action.slice(1);

					Swal.fire({
						title: `Are you sure you want to ${actionText.toLowerCase()} this application?`,
						icon: 'warning',
						showCancelButton: true,
						confirmButtonColor: '#3085d6',
						cancelButtonColor: '#d33',
						confirmButtonText: `Yes, ${actionText} it!`
					}).then((result) => {
						if (result.isConfirmed) {
							// Send AJAX request to update the application
							$.ajax({
								url: 'data/processors/forms/update_application.php',
								type: 'POST',
								data: {
									action: action,
									id: id,
									reason: reason
								},
								dataType: 'json',
								success: function(response) {
									if (response.status === 'success') {
										Swal.fire('Success', response.message, 'success');
										if (action === 'delete') {
											document.getElementById('application-row-' + id).remove();
										} else {
											setTimeout(() => {
												location.reload();
											}, 1000);
										}
									} else {
										Swal.fire('Error', response.message, 'error');
									}
								},
								error: function() {
									Swal.fire('Error', 'There was an error processing your request.', 'error');
								}
							});
						}
					});
				}
			});
		</script>
	</div>
</body>

</html>