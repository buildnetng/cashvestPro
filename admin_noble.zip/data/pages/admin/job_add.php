<?php include_once "data/includes/head.php"; ?>

<body>
    <div class="wrapper">
        <?php include_once "data/includes/header.php"; ?>
        <main class="content">
            <div class="container-fluid p-0">

                <h1 class="h3 mb-3">Add Job Data</h1>

                <div class="col-12 col-xl-12">
                    <div class="card">

                        <div class="card-body">

                            <form id="jobForm">
                                <!-- Job Title -->
                                <div class="mb-3">
                                    <label for="jobTitle" class="form-label">Job Title</label>
                                    <input type="text" class="form-control" id="jobTitle" name="job_title" >
                                </div>

                                <!-- Job Location -->
                                <div class="mb-3">
                                    <label for="jobLocation" class="form-label">Job Location</label>
                                    <input type="text" class="form-control" id="jobLocation" name="job_location" >
                                </div>

                                <!-- School Name -->
                                <div class="mb-3">
                                    <label for="schoolName" class="form-label">School Name</label>
                                    <input type="text" class="form-control" id="schoolName" name="school_name" >
                                </div>

                                <!-- Salary Range -->
                                <div class="mb-3">
                                    <label for="salaryRange" class="form-label">Salary Range</label>
                                    <input type="text" class="form-control" id="salaryRange" name="salary_range" >
                                </div>

                                <!-- Experience -->
                                <div class="mb-3">
                                    <label for="experience" class="form-label">Experience</label>
                                    <input type="text" class="form-control" id="experience" name="experience" >
                                </div>

                                <!-- Degree -->
                                <div class="mb-3">
                                    <label for="degree" class="form-label">Degree</label>
                                    <input type="text" class="form-control" id="degree" name="degree" >
                                </div>

                                <!-- Job Type -->
                                <div class="mb-3">
                                    <label for="jobType" class="form-label">Job Type</label>
                                    <input type="text" class="form-control" id="jobType" name="job_type" >
                                </div>

                                <!-- Company Name -->
                                <div class="mb-3">
                                    <label for="companyName" class="form-label">Company Name</label>
                                    <input type="text" class="form-control" id="companyName" name="company_name" >
                                </div>

                                <!-- Contact Email -->
                                <div class="mb-3">
                                    <label for="contactEmail" class="form-label">Contact Email</label>
                                    <input type="email" class="form-control" id="contactEmail" name="contact_email" >
                                </div>

                                <!-- Rich Text Editor for Description -->
                                <div class="mb-3">
                                    <label for="description" class="form-label">Description</label>
                                    <input type="hidden" id="description" name="description" >
                                    <div id="description-editor" style="height: 200px;"></div>
                                </div>

                                <!-- Application Deadline -->
                                <div class="mb-3">
                                    <label for="applicationDeadline" class="form-label">Application Deadline</label>
                                    <input type="date" class="form-control" id="applicationDeadline" name="application_deadline" >
                                </div>

                                <!-- Submit Button -->
                                <button type="submit" class="btn btn-primary">Submit Application</button>
                            </form>

                            <script>
                                // Initialize Quill editor
                                var quill = new Quill('#description-editor', {
                                    theme: 'snow',
                                    modules: {
                                        toolbar: true
                                    }
                                });

                                // Sync Quill editor content with hidden input field
                                quill.on('text-change', function() {
                                    document.querySelector('#description').value = quill.root.innerHTML;
                                });

                                // Handle form submission with AJAX
                                $('#jobForm').on('submit', function(e) {
                                    e.preventDefault();

                                    var form = $(this);
                                    var formData = form.serialize();

                                    $.ajax({
                                        url: 'data/processors/forms/process_job_form.php',
                                        type: 'POST',
                                        data: formData,
                                        dataType: 'json',
                                        success: function(response) {
                                            if (response.status === 'success') {
                                                Swal.fire('Success', response.messages.join('<br>'), 'success').then(function() {
                                                    // Reset Quill editor and form
                                                    quill.setContents([]);
                                                    form[0].reset(); // Reset form fields
                                                    document.querySelector('#description').value = ''; // Clear hidden input
                                                });
                                            } else {
                                                Swal.fire('Error', response.messages.join('<br>'), 'error');
                                            }
                                        },
                                        error: function() {
                                            Swal.fire('Error', 'An error occurred while submitting the form. Please try again.', 'error');
                                        }
                                    });
                                });
                            </script>


                        </div>
                    </div>
                </div>


            </div>
        </main>


        <script src="assets/js/app.js"></script>
</body>

</html>