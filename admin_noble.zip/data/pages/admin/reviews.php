<?php include_once "data/includes/head.php"; ?>

<body>
	<div class="wrapper">
		<?php include_once "data/includes/header.php"; ?>

		<main class="content">
			<div class="container-fluid p-0">

				<a data-bs-toggle="modal" data-bs-target="#reviewModal" class="btn btn-primary float-end mt-n1"><i class="fas fa-plus"></i> Add Review</a>
				<h1 class="h3 mb-3">Reviews</h1>
				<?php
				require_once 'data/processors/config.php';

				// Define the number of results per page
				$resultsPerPage = 5;

				// Get the current page number from the query string, default to page 1 if not set
				$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
				if ($page < 1) $page = 1; // Ensure page number is at least 1

				// Calculate the starting limit for the SQL query
				$startLimit = ($page - 1) * $resultsPerPage;

				// Initialize search parameters
				$searchName = isset($_GET['search_name']) ? $_GET['search_name'] : '';
				$searchEmail = isset($_GET['search_email']) ? $_GET['search_email'] : '';

				// Build the base SQL query
				$query = "SELECT `id`, `first_name`, `last_name`, `email`, `review_details`, `submitted_at`, `rating`, `posted_by`, `post_status` FROM `user_reviews` WHERE 1=1";

				// Add search filters to the SQL query if applicable
				if (!empty($searchName)) {
					$query .= " AND (`first_name` LIKE '%" . $mysqli->real_escape_string($searchName) . "%' OR `last_name` LIKE '%" . $mysqli->real_escape_string($searchName) . "%')";
				}
				if (!empty($searchEmail)) {
					$query .= " AND `email` LIKE '%" . $mysqli->real_escape_string($searchEmail) . "%'";
				}

				// Add limit for pagination
				$query .= " LIMIT $startLimit, $resultsPerPage";

				// Execute the query
				$result = $mysqli->query($query);

				// Fetch total number of reviews for pagination calculation
				$totalQuery = "SELECT COUNT(*) as total FROM `user_reviews` WHERE 1=1";
				if (!empty($searchName)) {
					$totalQuery .= " AND (`first_name` LIKE '%" . $mysqli->real_escape_string($searchName) . "%' OR `last_name` LIKE '%" . $mysqli->real_escape_string($searchName) . "%')";
				}
				if (!empty($searchEmail)) {
					$totalQuery .= " AND `email` LIKE '%" . $mysqli->real_escape_string($searchEmail) . "%'";
				}
				$totalResult = $mysqli->query($totalQuery);
				$totalRows = $totalResult->fetch_assoc()['total'];
				$totalPages = ceil($totalRows / $resultsPerPage);
				?>

				<!-- Search Form -->
				<form method="GET" action="">
					<div class="row mb-4">
						<div class="col-md-4">
							<input type="text" name="search_name" class="form-control" placeholder="Search by name" value="<?php echo htmlspecialchars($searchName); ?>">
						</div>
						<div class="col-md-4">
							<input type="text" name="search_email" class="form-control" placeholder="Search by email" value="<?php echo htmlspecialchars($searchEmail); ?>">
						</div>
						<div class="col-md-4">
							<button type="submit" class="btn btn-primary">Search</button>
						</div>
					</div>
				</form>

				<?php
				if ($result->num_rows > 0) {
					echo '<div class="row">';
					while ($row = $result->fetch_assoc()) {
						$avatar = 'img/avatars/avatar.jpg';
						$name = htmlspecialchars($row['first_name'] . ' ' . $row['last_name']);
						$reviewDate = date('F j, Y', strtotime($row['submitted_at']));
						$rating = intval($row['rating']); // Assuming rating is an integer between 1 and 5
						$reviewText = htmlspecialchars($row['review_details']);
						$email = htmlspecialchars($row['email']);
						$reviewId = intval($row['id']); // To use in action links
						$postStatus = $row['post_status'];

						// Generate star rating
						$starRating = str_repeat('<i class="fas fa-star"></i>', $rating);
						$starRating .= str_repeat('<i class="far fa-star"></i>', 5 - $rating);

						// Determine publish/unpublish button text and class
						$publishButton = $postStatus === 'approved'
							? '<button class="btn btn-sm btn-warning action-btn" data-action="unpublish" data-id="' . $reviewId . '">Unpublish Review</button>'
							: '<button class="btn btn-sm btn-success action-btn" data-action="publish" data-id="' . $reviewId . '">Publish Review</button>';

						echo '
        <div class="col-12 col-md-6 col-lg-4">
            <div class="card">
                <div class="card-body text-center">
                    <h5 class="card-title mb-1">' . $name . '</h5>
                    <p class="text-muted mb-2">Reviewed on ' . $reviewDate . '</p>
                    <div class="mb-3">
                        <span class="">' . $starRating . '</span>
                    </div>
                    <p class="card-text mt-3">' . $reviewText . '</p>
                    <p class="text-muted mt-3">
                        <small><i class="fas fa-envelope"></i> ' . $email . '</small>
                    </p>
                    <button class="btn btn-sm btn-info edit-review-btn" data-id="' . $reviewId . '" data-name="' . $name . '" data-text="' . $reviewText . '" data-rating="' . $rating . '">  <i class="fas fa-pencil-alt"></i></button>
                    <button class="btn btn-sm btn-danger action-btn" data-action="delete" data-id="' . $reviewId . '"> <i class="fas fa-trash"></i></button>
                    ' . $publishButton . '
                </div>
            </div>
        </div>';
					}
					echo '</div>';
				} else {
					echo '<p>No reviews available.</p>';
				}

				// Pagination Links
				echo '<nav aria-label="Page navigation">';
				echo '<ul class="pagination justify-content-center">';
				if ($page > 1) {
					echo '<li class="page-item"><a class="page-link" href="?page=' . ($page - 1) . '&search_name=' . urlencode($searchName) . '&search_email=' . urlencode($searchEmail) . '">Previous</a></li>';
				}
				for ($i = 1; $i <= $totalPages; $i++) {
					$active = ($i == $page) ? 'active' : '';
					echo '<li class="page-item ' . $active . '"><a class="page-link" href="?page=' . $i . '&search_name=' . urlencode($searchName) . '&search_email=' . urlencode($searchEmail) . '">' . $i . '</a></li>';
				}
				if ($page < $totalPages) {
					echo '<li class="page-item"><a class="page-link" href="?page=' . ($page + 1) . '&search_name=' . urlencode($searchName) . '&search_email=' . urlencode($searchEmail) . '">Next</a></li>';
				}
				echo '</ul>';
				echo '</nav>';

				// Close the connection
				$mysqli->close();
				?>


			</div>
		</main>

		<!-- Add Review Modal -->
		<div class="modal fade" id="reviewModal" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Add Review</h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					</div>
					<div class="modal-body mx-3">
						<form id="review-form">
							<label for="">Choose star</label>
							<div class="stars mb-3" id="star-rating">
								<span class="star" data-rating="1">&#9733;</span>
								<span class="star" data-rating="2">&#9733;</span>
								<span class="star" data-rating="3">&#9733;</span>
								<span class="star" data-rating="4">&#9733;</span>
								<span class="star" data-rating="5">&#9733;</span>
							</div>
							<div id="star-count" class="mb-3" style="font-size: 18px; color: #FFD700;">0 Stars</div>
							<input type="hidden" id="rating" name="rating" value="0">
							<div class="row mb-3">
								<div class="col">
									<input type="text" class="custom-input form-control" id="first_name" placeholder="First Name">
								</div>
								<div class="col">
									<input type="text" class="custom-input form-control" id="last_name" placeholder="Last Name">
								</div>
							</div>
							<div class="mb-3">
								<input type="email" class="custom-input form-control" id="email" placeholder="Your E-mail address">
							</div>
							<div class="mb-3">
								<textarea class="custom-input form-control" id="review_details" rows="3" placeholder="Review Details..."></textarea>
							</div>

					</div>
					<div class="modal-footer">
						<button class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
						<button class="btn btn-primary" type="submit">Submit Review</button>
					</div>
					</form>
				</div>
			</div>
		</div>


		<!-- Edit Review Modal -->
		<div class="modal fade" id="editReviewModal" tabindex="-1" aria-labelledby="editReviewModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="editReviewModalLabel">Edit Review</h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					</div>
					<div class="modal-body">
						<form id="editReviewForm">
							<input type="hidden" id="editReviewId" name="review_id">
							<div class="mb-3">
								<label for="editReviewerName" class="form-label">Reviewer Name</label>
								<input type="text" class="form-control" id="editReviewerName" name="reviewer_name" readonly>
							</div>
							<div class="mb-3">
								<label for="editReviewText" class="form-label">Review Text</label>
								<textarea class="form-control" id="editReviewText" name="review_text" rows="4" required></textarea>
							</div>
							<div class="mb-3">
								<label for="editRating" class="form-label">Rating</label>
								<select class="form-select" id="editRating" name="rating" required>
									<option value="1">1 Star</option>
									<option value="2">2 Stars</option>
									<option value="3">3 Stars</option>
									<option value="4">4 Stars</option>
									<option value="5">5 Stars</option>
								</select>
							</div>
							<button type="submit" class="btn btn-primary">Save Changes</button>
						</form>
					</div>
				</div>
			</div>
		</div>

		<script src="assets/js/app.js"></script>



		<script>
			$(document).ready(function() {
				// Star rating functionality
				$('#star-rating .star').css({
					'font-size': '30px', // Increase star size
					'cursor': 'pointer'
				}).on('mouseover', function() {
					var rating = $(this).data('rating');
					$('#star-rating .star').each(function(index) {
						if (index < rating) {
							$(this).css('color', '#FFD700'); // Gold color for selected stars
						} else {
							$(this).css('color', '#000'); // Default color for unselected stars
						}
					});
				}).on('click', function() {
					var rating = $(this).data('rating');
					$('#rating').val(rating);
					$('#star-count').text(rating + ' Star' + (rating > 1 ? 's' : '')); // Update star count
				}).on('mouseout', function() {
					var rating = $('#rating').val();
					$('#star-rating .star').each(function(index) {
						if (index < rating) {
							$(this).css('color', '#FFD700'); // Gold color for selected stars
						} else {
							$(this).css('color', '#000'); // Default color for unselected stars
						}
					});
				});

				// Handle form submission via AJAX
				$('#review-form').on('submit', function(e) {
					e.preventDefault();

					let first_name = $('#first_name').val();
					let last_name = $('#last_name').val();
					let email = $('#email').val();
					let review_details = $('#review_details').val();
					let rating = $('#rating').val();

					if (rating == 0) {
						Swal.fire({
							icon: 'error',
							title: 'Oops...',
							text: 'Please select a rating before submitting your review.'
						});
						return;
					}

					$.ajax({
						url: 'data/processors/forms/submit_review.php',
						type: 'POST',
						dataType: 'json',
						data: {
							first_name: first_name,
							last_name: last_name,
							email: email,
							review_details: review_details,
							rating: rating
						},
						success: function(response) {
							if (response.status === 'success') {
								Swal.fire({
									icon: 'success',
									title: 'Thank you!',
									text: response.message
								}).then(() => location.reload());
								$('#star-rating .star').css('color', '#000');
								$('#rating').val('0');
								$('#star-count').text('0 Stars');
								$('#feedback-modal').animate({
									right: '-100%'
								}, 400, function() {
									$(this).hide();
								});

							} else {
								Swal.fire({
									icon: 'error',
									title: 'Oops...',
									text: response.message
								});
							}
						},
						error: function() {
							Swal.fire({
								icon: 'error',
								title: 'Error!',
								text: 'An unexpected error occurred. Please try again.'
							});
						}
					});
				});

				// Handle feedback modal toggle
				$('#Feedbacks').click(function() {
					if ($('#feedback-modal').is(':visible')) {
						$('#feedback-modal').animate({
							right: '-100%'
						}, 400, function() {
							$(this).hide();
						});
					} else {
						$('#feedback-modal').css('right', '-100%').show().animate({
							right: '20px'
						}, 400);
					}
				});

				// Close feedback modal
				$('#close-modal').click(function() {
					$('#feedback-modal').animate({
						right: '-100%'
					}, 400, function() {
						$(this).hide();
					});
				});
			});
		</script>

		<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

		<script>
			$(document).ready(function() {
				let currentReviewId = null;

				// Handle click events for action buttons
				$('.action-btn').click(function() {
					const action = $(this).data('action');
					const id = $(this).data('id');
					currentReviewId = id;

					switch (action) {


						case 'delete':
							Swal.fire({
								title: 'Are you sure?',
								text: "You won't be able to revert this!",
								icon: 'warning',
								showCancelButton: true,
								confirmButtonColor: '#3085d6',
								cancelButtonColor: '#d33',
								confirmButtonText: 'Yes, delete it!'
							}).then((result) => {
								if (result.isConfirmed) {
									$.ajax({
										url: 'data/processors/forms/delete_review.php',
										method: 'GET',
										data: {
											id: id
										},
										dataType: 'json',
										success: function(response) {
											if (response.status === 'success') {
												Swal.fire('Deleted!', response.message, 'success')
													.then(() => location.reload());
											} else {
												Swal.fire('Error!', response.message, 'error');
											}
										}
									});
								}
							});
							break;

						case 'publish':
						case 'unpublish':
							Swal.fire({
								title: 'Are you sure?',
								text: action === 'publish' ? "Publish this review?" : "Unpublish this review?",
								icon: 'warning',
								showCancelButton: true,
								confirmButtonColor: '#3085d6',
								cancelButtonColor: '#d33',
								confirmButtonText: action === 'publish' ? 'Yes, publish it!' : 'Yes, unpublish it!'
							}).then((result) => {
								if (result.isConfirmed) {
									$.ajax({
										url: 'data/processors/forms/toggle_publish.php',
										method: 'POST',
										data: {
											id: id,
											action: action
										},
										dataType: 'json',
										success: function(response) {
											if (response.status === 'success') {
												Swal.fire('Success!', response.message, 'success')
													.then(() => location.reload());
											} else {
												Swal.fire('Error!', response.message, 'error');
											}
										}
									});
								}
							});
							break;
					}
				});
			});
		</script>
		<script>
			document.addEventListener('DOMContentLoaded', function() {
				// Handle edit button click
				document.querySelectorAll('.edit-review-btn').forEach(function(button) {
					button.addEventListener('click', function() {
						// Get review data from button attributes
						const reviewId = this.getAttribute('data-id');
						const reviewerName = this.getAttribute('data-name');
						const reviewText = this.getAttribute('data-text');
						const rating = this.getAttribute('data-rating');

						// Populate modal form with review data
						document.getElementById('editReviewId').value = reviewId;
						document.getElementById('editReviewerName').value = reviewerName;
						document.getElementById('editReviewText').value = reviewText;
						document.getElementById('editRating').value = rating;

						// Show the modal
						const modal = new bootstrap.Modal(document.getElementById('editReviewModal'));
						modal.show();
					});
				});

				// Handle form submission
				document.getElementById('editReviewForm').addEventListener('submit', function(event) {
					event.preventDefault();

					const formData = new FormData(this);

					// SweetAlert confirmation dialog
					Swal.fire({
						title: 'Are you sure?',
						text: "Do you want to save the changes?",
						icon: 'warning',
						showCancelButton: true,
						confirmButtonText: 'Yes, save it!',
						cancelButtonText: 'No, cancel'
					}).then((result) => {
						if (result.isConfirmed) {
							// Send the form data using AJAX
							fetch('data/processors/forms/update_review.php', {
									method: 'POST',
									body: formData
								})
								.then(response => response.json())
								.then(data => {
									if (data.success) {
										Swal.fire('Saved!', 'The review has been updated.', 'success')
											.then(() => location.reload());
									} else {
										Swal.fire('Error!', data.message, 'error');
									}
								})
								.catch(error => {
									console.error('Error updating review:', error);
									Swal.fire('Error!', 'An error occurred while updating the review.', 'error');
								});
						}
					});
				});
			});
		</script>



</body>

</html>