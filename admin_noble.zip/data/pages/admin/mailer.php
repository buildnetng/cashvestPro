<?php include_once "data/includes/head.php"; ?>

<body>
	<div class="wrapper">
		<?php include_once "data/includes/header.php"; ?>

		<main class="content">
			<div class="container-fluid p-0">
				<h1 class="h3 mb-3">Send Mail</h1>

				<div class="col-12 col-xl-12">
					<div class="card">
						<div class="card-body">
							<form id="emailForm">
								<div class="mb-3">
									<label class="form-label">Subject</label>
									<input type="text" class="form-control" name="subject" placeholder="Subject">
								</div>
								<div class="mb-3">
									<label class="form-label">Email address</label>
									<input type="email" class="form-control" name="email" placeholder="Email">
								</div>
								<div class="mb-5">
									<label for="description" class="form-label">Mail content</label>
									<div id="description-editor" style="height: 200px;"></div>
									<textarea class="form-control" id="description" name="description" style="display:none;"></textarea>
								</div>
								<button type="submit" class="btn btn-primary">Send</button>
							</form>

							<!-- Include SweetAlert and jQuery -->
							<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
							<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
							<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>

							<script>
								// Initialize the Quill editor for email content
								var quill = new Quill('#description-editor', { theme: 'snow' });

								$('#emailForm').on('submit', function(e) {
									e.preventDefault();

									// Transfer the editor content to the hidden textarea
									$('#description').val(quill.root.innerHTML);

									// Serialize form data
									var formData = $(this).serialize();

									// AJAX request to send the form data
									$.ajax({
										url: 'data/processors/forms/mailer.php',
										type: 'POST',
										data: formData,
										dataType: 'json',  // Expect JSON response
										success: function(response) {
											// Handle the JSON response from PHP
											if (response.status === 'success') {
												Swal.fire({
													icon: 'success',
													title: 'Email Sent!',
													text: response.message
												});
											} else {
												Swal.fire({
													icon: 'error',
													title: 'Oops...',
													text: response.message
												});
											}
										},
										error: function(xhr, status, error) {
											Swal.fire({
												icon: 'error',
												title: 'Error',
												text: 'An error occurred while sending the email.'
											});
										}
									});
								});
							</script>

						</div>
					</div>
				</div>
			</div>
		</main>

		<script src="assets/js/app.js"></script>
</body>
</html>
