<?php
include_once "data/includes/head.php";
require_once 'data/processors/config.php';

// Check if the connection is established
if (!$mysqli) {
    die("Database connection failed.");
}

// Initialize variables for search and pagination
$search = isset($_GET['search']) ? $_GET['search'] : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10; // Number of records per page
$offset = ($page - 1) * $limit;

// Modify SQL query for search and pagination
$sql = "SELECT `id`, `job_id`, `email`, `report_reason`, `additional_info`, `date_reported` FROM `job_comments` WHERE 1";

if (!empty($search)) {
    $sql .= " AND (`email` LIKE ? OR `report_reason` LIKE ?)";
}

$sql .= " ORDER BY `date_reported` DESC LIMIT ? OFFSET ?";

// Prepare and execute the SQL statement
$stmt = $mysqli->prepare($sql);

if (!$stmt) {
    die("Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error);
}

// Bind parameters dynamically
if (!empty($search)) {
    $likeSearch = "%" . $search . "%";
    $stmt->bind_param("ssii", $likeSearch, $likeSearch, $limit, $offset);
} else {
    $stmt->bind_param("ii", $limit, $offset);
}

$stmt->execute();
$result = $stmt->get_result();

// Fetch the results
$reports = $result->fetch_all(MYSQLI_ASSOC);

// Get the total number of records for pagination
$total_records_sql = "SELECT COUNT(*) FROM `job_comments` WHERE 1";
if (!empty($search)) {
    $total_records_sql .= " AND (`email` LIKE ? OR `report_reason` LIKE ?)";
    $stmt = $mysqli->prepare($total_records_sql);
    $stmt->bind_param("ss", $likeSearch, $likeSearch);
} else {
    $stmt = $mysqli->prepare($total_records_sql);
}
$stmt->execute();
$stmt->bind_result($total_records);
$stmt->fetch();
$stmt->close();

$total_pages = ceil($total_records / $limit);
?>


<body>
    <div class="wrapper">
        <?php include_once "data/includes/header.php"; ?>

        <main class="content">
            <div class="container-fluid p-0">
                <div class="card">
                    <div class="card-body">

                        <div class="col-lg-4"> <!-- Search Form -->
                            <form method="GET" class="mb-3">
                                <div class="input-group">
                                    <input type="text" class="form-control" name="search" placeholder="Search by email or reason" value="<?php echo htmlspecialchars($search); ?>">
                                    <button class="btn btn-primary" type="submit">Search</button>
                                </div>
                            </form>
                        </div>
                        <table class="table w-100">
                            <thead>
                                <tr>
                                    <th class="align-middle w-25px">
                                        <div class="form-check fs-4">
                                            <input class="form-check-input tasks-check-all" type="checkbox" id="tasks-check-all">
                                            <label class="form-check-label" for="tasks-check-all"></label>
                                        </div>
                                    </th>
                                    <th>Job ID</th>
                                    <th>Email</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($reports as $report) : ?>
                                    <tr id="application-row-<?php echo $report['id']; ?>">
                                        <td>
                                            <div class="form-check fs-4">
                                                <input class="form-check-input" type="checkbox" id="checkbox-<?php echo $report['id']; ?>">
                                                <label class="form-check-label" for="checkbox-<?php echo $report['id']; ?>"></label>
                                            </div>
                                        </td>
                                        <td><?php echo htmlspecialchars($report['job_id']); ?></td>
                                        <td><?php echo htmlspecialchars($report['email']); ?></td>
                                        <td><?php echo htmlspecialchars($report['date_reported']); ?></td>
                                        <td class="text-end">
                                            <div class="dropdown">
                                                <button class="btn btn-light dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                                    Actions
                                                </button>
                                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                    <li>
                                                        <button type="button" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#viewModal-<?php echo $report['id']; ?>">View Details</button>
                                                    </li>
                                                    <li><a class="dropdown-item text-danger btn-delete" href="#" data-id="<?php echo $report['id']; ?>">Reply</a></li>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>

                                    <!-- View Details Modal for Each Report -->
                                    <div class="modal fade" id="viewModal-<?php echo $report['id']; ?>" tabindex="-1" aria-labelledby="viewModalLabel-<?php echo $report['id']; ?>" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="viewModalLabel-<?php echo $report['id']; ?>">Report Details</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><strong>Job ID:</strong> <?php echo htmlspecialchars($report['job_id']); ?></p>
                                                    <p><strong>Email:</strong> <?php echo htmlspecialchars($report['email']); ?></p>
                                                    <p><strong>Report Reason:</strong> <?php echo htmlspecialchars($report['report_reason']); ?></p>
                                                    <p><strong>Additional Info:</strong> <?php echo htmlspecialchars($report['additional_info']); ?></p>
                                                    <p><strong>Date Reported:</strong> <?php echo htmlspecialchars($report['date_reported']); ?></p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </tbody>
                        </table>

                        <!-- Pagination -->
                        <nav aria-label="Page navigation example">
                            <ul class="pagination justify-content-center">
                                <li class="page-item <?php if ($page <= 1) echo 'disabled'; ?>">
                                    <a class="page-link" href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>">Previous</a>
                                </li>
                                <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
                                    <li class="page-item <?php if ($i == $page) echo 'active'; ?>">
                                        <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>"><?php echo $i; ?></a>
                                    </li>
                                <?php endfor; ?>
                                <li class="page-item <?php if ($page >= $total_pages) echo 'disabled'; ?>">
                                    <a class="page-link" href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>">Next</a>
                                </li>
                            </ul>
                        </nav>

                    </div>
                </div>
            </div>
        </main>

        <script src="assets/js/app.js"></script>
    </div>
</body>

</html>