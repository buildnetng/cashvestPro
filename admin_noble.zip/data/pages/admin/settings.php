<?php include_once "data/includes/head.php";
require_once 'data/processors/site_data.php'; ?>


<body>
    <div class="wrapper">
        <?php include_once "data/includes/header.php"; ?>



        <main class="content">
            <div class="page-content">
                <div class="container-fluid">
                    <!-- start page title -->
                    <div class="row mb-3">
                        <div class="col-12">
                            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                <h4 class="mb-sm-0">System Information</h4>
                            </div>
                        </div>
                    </div>
                    <!-- end page title -->
                    <form id="system_info">
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <!-- Site Information Section -->
                                        <section>
                                            <h5>Site Information</h5>
                                            <div class="form-group row mb-2">
                                                <label for="site_title" class="col-md-2 col-form-label">Site Title</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="text" value="<?= !empty($site_title) ? $site_title : '' ?>" name="site_title" id="site_title">

                                                </div>
                                            </div>

                                            <div class="form-group row mb-2">
                                                <label for="meta_keywords" class="col-md-2 col-form-label">Meta Keywords</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="text" id="meta_keywords" name="meta_keywords" value="<?= !empty($meta_keywords) ? $meta_keywords : '' ?>">
                                                </div>
                                            </div>

                                            <div class="form-group row mb-2">
                                                <label for="meta_desc" class="col-md-2 col-form-label">Meta Description</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="text" name="meta_desc" value="<?= !empty($meta_desc) ? $meta_desc : '' ?>" id="meta_desc">
                                                </div>
                                            </div>

                                            <div class="form-group row mb-2">
                                                <label for="meta_author" class="col-md-2 col-form-label">Meta Author</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="text" name="meta_author" value="<?= !empty($meta_author) ? $meta_author : '' ?>" id="meta_author">
                                                </div>
                                            </div>

                                            <div class="form-group row mb-2">
                                                <label for="theme_color" class="col-md-2 col-form-label">Theme Color</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="color" id="theme_color" name="theme_color" value="<?= !empty($theme_color) ? $theme_color : '' ?>">
                                                </div>
                                            </div>
                                            <hr>
                                        </section>

                                        <!-- Company Contact Information Section -->
                                        <section>
                                            <h5>Company Contact Information</h5>
                                            <div class="form-group row mb-2">
                                                <label for="company_phone" class="col-md-2 col-form-label">Company Phone Number</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="tel" id="company_phone" name="company_phone" value="<?= !empty($company_phone) ? $company_phone : '' ?>">
                                                </div>
                                            </div>

                                            <div class="form-group row mb-2">
                                                <label for="company_email" class="col-md-2 col-form-label">Company Email</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="email" id="company_email" name="company_email" value="<?= !empty($company_email) ? $company_email : '' ?>">
                                                </div>
                                            </div>

                                            <div class="form-group row mb-2">
                                                <label for="company_address" class="col-md-2 col-form-label">Company Address</label>
                                                <div class="col-md-10">
                                                    <textarea class="form-control" id="company_address" name="company_address" rows="3"> <?= !empty($company_address) ? $company_address : '' ?></textarea>
                                                </div>
                                            </div>
                                            <hr>
                                        </section>

                                        <!-- SMTP Settings Section -->
                                        <section>
                                            <h5>SMTP Settings</h5>
                                            <div class="form-group row mb-2">
                                                <label for="gmail_account" class="col-md-2 col-form-label">GMail Account Email (SMTP)</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="email" required="required" name="gmail_account" value="<?= !empty($gmail_account) ? $gmail_account : '' ?>" id="gmail_account">
                                                </div>
                                            </div>

                                            <div class="form-group row mb-2">
                                                <label for="gmail_password" class="col-md-2 col-form-label">GMail Account Password</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="password" required="required" name="gmail_password" value="<?= !empty($gmail_password) ? $gmail_password : '' ?>" id="gmail_password">
                                                </div>
                                            </div>

                                            <div class="form-group row mb-2">
                                                <label for="reply_to_address" class="col-md-2 col-form-label">Reply-To Email Address</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="email" required="required" name="reply_to_address" value="<?= !empty($reply_to_address) ? $reply_to_address : '' ?>" id="reply_to_address">
                                                </div>
                                            </div>
                                            <hr>
                                        </section>

                                        <!-- General Settings Section -->
                                        <section>
                                            <h5>General Settings</h5>
                                            <div class="form-group row mb-2">
                                                <label for="pagination_number" class="col-md-2 col-form-label">Items Per Post page</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="number" name="pagination_number" value="<?= !empty($pagination_number) ? $pagination_number : '' ?>" id="pagination_number" min="1">
                                                </div>
                                            </div>

                                            <div class="form-group row mb-2">
                                                <label for="logo" class="col-md-2 col-form-label">Site Logo</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="file" name="logo" id="logo" accept="image/*">
                                                </div>
                                            </div>

                                            <div class="form-group row mb-2">
                                                <label for="favicon" class="col-md-2 col-form-label">Site Favicon</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="file" name="favicon" id="favicon" accept="image/x-icon, image/png">
                                                </div>
                                            </div>

                                            <div class="form-group row mb-2">
                                                <label for="site_url" class="col-md-2 col-form-label">Site URL</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="url" name="site_url" id="site_url" value="<?= !empty($site_url) ? $site_url : '' ?>">
                                                </div>
                                            </div>

                                            <div class="form-group row mb-2">
                                                <label for="account_url" class="col-md-2 col-form-label">Account URL</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="url" name="account_url" id="account_url" value="<?= !empty($account_url) ? $account_url : '' ?>">
                                                </div>
                                            </div>
                                            <hr>
                                        </section>

                                        <!-- Application Settings Section -->
                                        <section>
                                            <h5>Application Settings</h5>

                                            <!-- Can Users Apply for Multiple Jobs? -->
                                            <div class="form-group row mb-2">
                                                <label for="multiple_jobs" class="col-md-2 col-form-label">Can Users Apply for Multiple Jobs?</label>
                                                <div class="col-md-10">
                                                    <select class="form-control" name="multiple_jobs" id="multiple_jobs">
                                                        <option <?= !empty($multiple_jobs) && $multiple_jobs == "yes" ? 'selected' : '' ?> value="yes">Yes</option>
                                                        <option <?= !empty($multiple_jobs) && $multiple_jobs == "no" ? 'selected' : '' ?> value="no">No</option>
                                                    </select>

                                                </div>
                                            </div>

                                            <!-- Can Users Apply for Different Jobs with Same CV? -->
                                            <div class="form-group row mb-2" id="same_cv_section" style="display: none;">
                                                <label for="same_cv" class="col-md-2 col-form-label">Can Users Apply for Different Jobs with Same CV?</label>
                                                <div class="col-md-10">
                                                    <select class="form-control" name="same_cv" id="same_cv">
                                                        <option <?= !empty($same_cv) && $same_cv == "yes" ? 'selected' : '' ?> value="yes">Yes</option>
                                                        <option <?= !empty($same_cv) && $same_cv == "no" ? 'selected' : '' ?> value="no">No</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <!-- Allow User Feedback? -->
                                            <div class="form-group row mb-2">
                                                <label for="allow_feedback" class="col-md-2 col-form-label">Do You Wish to Allow User Feedback?</label>
                                                <div class="col-md-10">
                                                    <select class="form-control" name="allow_feedback" id="allow_feedback">
                                                        <option <?= !empty($allow_feedback) && $allow_feedback == "yes" ? 'selected' : '' ?> value="yes">Yes</option>
                                                        <option <?= !empty($allow_feedback) && $allow_feedback == "no" ? 'selected' : '' ?> value="no">No</option>
                                                    </select>
                                                </div>
                                            </div>




                                            <div class="form-group row mb-2">
                                                <label for="mentainace_mode" class="col-md-2 col-form-label">Enable Mentainace Mode</label>
                                                <div class="col-md-10">
                                                    <select class="form-control" name="mentainace_mode" id="mentainace_mode">
                                                        <option <?= !empty($mentainace_mode) && $mentainace_mode == "yes" ? 'selected' : '' ?> value="yes">Yes</option>
                                                        <option <?= !empty($mentainace_mode) && $mentainace_mode == "no" ? 'selected' : '' ?> value="no">No</option>
                                                    </select>
                                                </div>
                                            </div>

                                        </section>


                                        <!-- Save Button -->
                                        <div class="text-right">
                                            <button type="submit" class="btn btn-primary" data-scroll="no">Save</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>


                    <!-- JavaScript to Handle Conditional Display -->
                    <script>
                        document.getElementById('multiple_jobs').addEventListener('change', function() {
                            const sameCvSection = document.getElementById('same_cv_section');
                            if (this.value === 'yes') {
                                sameCvSection.style.display = 'block';
                            } else {
                                sameCvSection.style.display = 'none';
                            }
                        });

                        $(document).ready(function() {
                            $("#system_info").on('submit', function(e) {
                                e.preventDefault();
                                $.ajax({
                                    url: "data/processors/forms/site-data.php",
                                    type: "POST",
                                    data: new FormData(this),
                                    contentType: false,
                                    cache: false,
                                    processData: false,
                                    success: function(data) {
                                        if (data.trim() === 'success') {
                                            Swal.fire({
                                                icon: 'success',
                                                title: 'Success',
                                                text: 'Setup updated successfully',
                                                timer: 2000,
                                                showConfirmButton: false
                                            });
                                        } else {
                                            Swal.fire({
                                                icon: 'error',
                                                title: 'Error',
                                                text: data,
                                            });
                                        }
                                    },
                                    error: function(xhr, status, error) {
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Error',
                                            text: 'An error occurred while processing your request. Please try again later.'
                                        });
                                    }
                                });
                            });
                        });
                    </script>
                </div>

            </div>
        </main>
        <script src="assets//js/app.js"></script>

</body>

</html>