<?php include_once "data/includes/head.php"; ?>

<body>
	<div class="wrapper">
		<?php include_once "data/includes/header.php"; ?>

		<main class="content">
			<div class="container-fluid p-0">

				<h1 class="h3 mb-3">Settings</h1>

				<div class="row">
					<div class="col-md-3 col-xl-2">
						<div class="card">
							<div class="card-header">
								<h5 class="card-title mb-0">Profile Settings</h5>
							</div>
							<div class="list-group list-group-flush" role="tablist">
								<a class="list-group-item list-group-item-action active" data-bs-toggle="list" href="#account" role="tab">
									<i class="fas fa-user-circle me-2"></i>Account
								</a>
								<a class="list-group-item list-group-item-action" data-bs-toggle="list" href="#password" role="tab">
									<i class="fas fa-lock me-2"></i>Password
								</a>
							</div>
						</div>
					</div>

					<div class="col-md-9 col-xl-10">
						<div class="tab-content">
							<!-- Account Tab -->
							<div class="tab-pane fade show active" id="account" role="tabpanel">


								<div class="card">
									<div class="card-header d-flex justify-content-between align-items-center">
										<h5 class="card-title mb-0">Profile Information</h5>

									</div>
									<?php
									// Assuming $user["full_name"] is a single string like "John Doe"
									if (!empty($user["full_name"])) {
										$result = explode(' ', $user["full_name"]);
										$firstname = isset($result[0]) ? $result[0] : '';
										$lastname = isset($result[1]) ? $result[1] : '';
									} else {
										$firstname = '';
										$lastname = '';
									}
									?>

									<div class="card-body">
										<form id="userForm">
											<div class="row">
												<div class="mb-3 col-md-6">
													<label for="inputFirstName" class="form-label">First Name</label>
													<input type="text"  class="form-control" id="inputFirstName" name="first_name" placeholder="First name" value="<?= htmlspecialchars($firstname) ?>">
												</div>
												<div class="mb-3 col-md-6">
													<label for="inputLastName" class="form-label">Last Name</label>
													<input type="text"  class="form-control" id="inputLastName" name="last_name" placeholder="Last name" value="<?= htmlspecialchars($lastname) ?>">
												</div>
											</div>
											<div class="mb-3">
												<label for="inputEmail4" class="form-label">Email</label>
												<input type="email"  class="form-control" id="inputEmail4" name="email" placeholder="Email" value="<?= htmlspecialchars($user['email']) ?>">
											</div>
											<button type="submit" class="btn btn-primary">Save changes</button>
										</form>


									</div>

								</div>
							</div>

							<!-- Password Tab -->
							<div class="tab-pane fade" id="password" role="tabpanel">
								<div class="card">
									<div class="card-header">
										<h5 class="card-title mb-0">Password Settings</h5>
									</div>
									<div class="card-body">
										<form id="changepassword">
											<div class="mb-3">
												<label for="inputPasswordCurrent" class="form-label">Current Password</label>
												<input type="password" class="form-control" id="inputPasswordCurrent" name="currentPassword" placeholder="Current password" required>
											</div>
											<div class="mb-3">
												<label for="inputPasswordNew" class="form-label">New Password</label>
												<input type="password" class="form-control" id="inputPasswordNew" name="newPassword" placeholder="New password" required>
											</div>
											<div class="mb-3">
												<label for="inputPasswordNew2" class="form-label">Confirm Password</label>
												<input type="password" class="form-control" id="inputPasswordNew2" name="confirmPassword" placeholder="Confirm new password" required>
											</div>
											<button type="submit" class="btn btn-primary">Save changes</button>
											<div id="messageContainer" class="message-container">
												<i id="messageIcon" class="message-icon fas"></i>
												<p id="messageText"></p>
											</div>
										</form>

									</div>
								</div>
							</div>

						</div>
					</div>
				</div>

			</div>
		</main>
		<script src="assets/js/app.js"></script>

		
		<script>
			$(document).ready(function() {
				$('#changepassword').on('submit', function(e) {
					e.preventDefault();

					var form = $(this);
					var button = form.find('button[type="submit"]');
					var originalButtonText = button.text();
					var formData = form.serialize();

					// Show loading text and disable the button
					button.text('Please wait...').prop('disabled', true);

					$.ajax({
						url: 'data/processors/forms/process_updatepass.php',
						type: 'POST',
						data: formData,
						dataType: 'json',
						success: function(response) {
							setTimeout(function() {
								// Restore button state
								button.text(originalButtonText).prop('disabled', false);

								if (response.status === 'success') {
									Swal.fire({
										icon: 'success',
										title: 'Password Changed',
										text: 'Your password has been changed successfully.',
										timer: 3000,
										showConfirmButton: false
									}).then(() => {
										window.location.href = 'home'; // Redirect if needed
									});
								} else {
									Swal.fire({
										icon: 'error',
										title: 'Error',
										html: response.messages.join('<br>'),
										timer: 3000,
										showConfirmButton: false
									});
								}
							}, 3000);
						},
						error: function(xhr, status, error) {
							setTimeout(function() {
								button.text(originalButtonText).prop('disabled', false);
								Swal.fire({
									icon: 'error',
									title: 'Submission Failed',
									text: 'Form submission failed, please try again.',
									timer: 3000,
									showConfirmButton: false
								});
							}, 3000);
						}
					});
				});
			});
		</script>

			<script>
			$(document).ready(function() {
				$('#userForm').on('submit', function(e) {
					e.preventDefault();

					var form = $(this);
					var button = form.find('button[type="submit"]');
					var originalButtonText = button.text();
					var formData = form.serialize();

					// Show loading text and disable the button
					button.text('Saving...').prop('disabled', true);

					$.ajax({
						url: 'data/processors/forms/process_update_profile.php',
						type: 'POST',
						data: formData,
						dataType: 'json',
						success: function(response) {
							setTimeout(function() {
								// Restore button state
								button.text(originalButtonText).prop('disabled', false);

								if (response.status === 'success') {
									Swal.fire({
										icon: 'success',
										title: 'Profile Updated',
										text: 'Your profile has been updated successfully.',
										timer: 3000,
										showConfirmButton: false
									});
								} else {
									Swal.fire({
										icon: 'error',
										title: 'Update Failed',
										html: response.messages.join('<br>'),
										timer: 3000,
										showConfirmButton: false
									});
								}
							}, 2000); // Adjust timing if necessary
						},
						error: function(xhr, status, error) {
							setTimeout(function() {
								button.text(originalButtonText).prop('disabled', false);
								Swal.fire({
									icon: 'error',
									title: 'Submission Failed',
									text: 'Form submission failed, please try again.',
									timer: 3000,
									showConfirmButton: false
								});
							}, 2000); // Adjust timing if necessary
						}
					});
				});
			});
		</script>


</body>

</html>