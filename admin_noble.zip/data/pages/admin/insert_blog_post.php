<?php include_once "data/includes/head.php"; ?>

<body>
    <div class="wrapper">
        <?php include_once "data/includes/header.php"; ?>
        <main class="content">
            <div class="container-fluid p-0">

                <h1 class="h3 mb-3">Add Job Data</h1>

                <div class="col-12 col-xl-12">
                    <div class="card">

                        <div class="card-body">
                            <form id="blogPost" enctype="multipart/form-data">
                                <!-- Blog Title -->
                                <div class="mb-3">
                                    <label for="jobTitle" class="form-label">Blog Title</label>
                                    <input type="text" class="form-control" id="jobTitle" name="blog_title" required>
                                </div>

                                <!-- Rich Text Editor for Description -->
                                <div class="mb-3">
                                    <label for="description" class="form-label">Description</label>
                                    <input type="hidden" id="description" name="description" required>
                                    <div id="blog-contents-editor" style="height: 200px;"></div>
                                </div>

                                <!-- Image Upload -->
                                <div class="mb-3">
                                    <label for="blogImage" class="form-label">Upload Image</label>
                                    <input type="file" class="form-control" id="blogImage" name="blog_image" accept="image/*" required>
                                </div>

                                <!-- Submit Button -->
                                <button type="submit" class="btn btn-primary">Submit Blog Post</button>
                            </form>

                            <script>
                                // Initialize Quill editor
                                var quill = new Quill('#blog-contents-editor', {
                                    theme: 'snow',
                                    modules: {
                                        toolbar: true
                                    }
                                });

                                // Sync Quill editor content with hidden input field
                                quill.on('text-change', function() {
                                    document.querySelector('#description').value = quill.root.innerHTML;
                                });

                                // Handle form submission with AJAX
                                $('#blogPost').on('submit', function(e) {
                                    e.preventDefault();

                                    var formData = new FormData(this); // Use FormData to handle file uploads

                                    $.ajax({
                                        url: 'data/processors/forms/process_blog.php',
                                        type: 'POST',
                                        data: formData,
                                        processData: false,
                                        contentType: false,
                                        dataType: 'json',
                                        success: function(response) {
                                            if (response.status === 'success') {
                                                Swal.fire('Success', response.message, 'success').then(function() {
                                                    // Reset Quill editor and form
                                                    quill.setContents([]);
                                                    $('#blogPost')[0].reset(); // Reset form fields
                                                    document.querySelector('#description').value = ''; // Clear hidden input
                                                });
                                            } else {
                                                Swal.fire('Error', response.message, 'error');
                                            }
                                        },
                                        error: function() {
                                            Swal.fire('Error', 'An error occurred while submitting the form. Please try again.', 'error');
                                        }
                                    });
                                });
                            </script>

                        </div>
                    </div>
                </div>


            </div>
        </main>


        <script src="assets/js/app.js"></script>
</body>

</html>