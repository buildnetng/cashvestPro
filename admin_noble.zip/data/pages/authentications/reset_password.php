<?php include_once "data/includes/head-auth.php"; ?>

<body>
    <form id="reset_password_form">
        <input type="hidden" name="token" value="<?php echo htmlspecialchars($_GET['token']); ?>">
        <label for="password">New Password:</label>
        <input type="password" id="password" name="password" required>
        <button type="submit">Reset Password</button>
    </form>
    <?php include_once "data/includes/footer.php"; ?>
</body>

</html>