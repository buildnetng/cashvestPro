<?php
include_once "data/includes/head-auth.php";

// Start the session
session_start();

// Check if the user is already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: home");
    exit;
}

// Display a message if the user has just logged out
$logoutMessage = '';
if (isset($_GET['loggedout']) && $_GET['loggedout'] === 'yes') {
    $logoutMessage = '<div class="alert alert-success p-3">You have been successfully logged out.</div>';
}

// Display status messages based on query parameters
$status = isset($_GET['status']) ? $_GET['status'] : '';

switch ($status) {
    case 'session_timed_out':
        $alert = '<div class="alert alert-warning p-3">Your session has timed out. Please log in again.</div>';
        break;
    case 'unauthorized_access':
        $alert = '<div class="alert alert-danger p-3">Unauthorized access. Please log in.</div>';
        break;
    case 'user_not_logged_in':
        $alert = '<div class="alert alert-danger p-3">You are not logged in. Please log in.</div>';
        break;
    case 'session_email_mismatch':
        $alert = '<div class="alert alert-danger p-3">Session email mismatch. Please log in again.</div>';
        break;


    case 'access_denied':
        $alert = '<div class="alert alert-danger p-3">Access denied. Admin privileges required.</div>';
        break;
    case 'reset_token_expired':
        $alert = '<div class="alert alert-danger p-3">Password reset token has expired. Please request a new one.</div>';
        break;

    case 'user_not_found':
        $alert = '<div class="alert alert-danger p-3">User not found. Please log in again.</div>';
        break;
    default:
        $alert = '';
        break;
}

?>


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.css">
<style>
    .toggle-password {
        cursor: pointer;
        position: absolute;
        right: 10px;
        top: 53%;

    }

    .toggle-password2 {
        cursor: pointer;
        position: absolute;
        right: 10px;
        top: 53%;

    }

    .toggle-password3 {
        cursor: pointer;
        position: absolute;
        right: 10px;
        top: 53%;

    }

    .password-wrapper {
        position: relative;
    }

    .rc-anchor-light {
        background: #ffffff17 !important;
        color: #2c7a7b !important;
    }

    #passwordStrengthWrapper {
        display: none;
        position: absolute;
        background-color: white;
        z-index: 5;
    }
</style>


<style>
    /* CSS for Uniform Input Field */
    .custom-input {
        width: 100% !important;
        padding: 12px 15px !important;
        margin: 8px 0 !important;
        display: inline-block !important;
        border: 1px solid #ffffff4a !important;
        border-radius: 4px !important;
        box-sizing: border-box !important;
        font-size: 16px !important;
        background-color: transparent !important;
        color: #333 !important;
        transition: border-color 0.3s, background-color 0.3s !important;
    }

    /* Hover Effect */
    .custom-input:hover {
        border-color: #ffffff4a !important;
        background-color: transparent !important;
        border: 1px solid #626363 !important;
    }

    /* Focus Effect */
    .custom-input:focus {
        outline: none !important;
        border-color: wheat !important;
        border-width: 1px !important;
    }

    #passwordStrengthWrapper {
        width: 100%;
    }

    #passwordStrengthBar {
        height: 8px;
    }

    .progress-bar {
        transition: width 0.5s;
    }

    .text-success {
        color: green;
    }

    .text-danger {
        color: red;
    }

    #passwordRequirements {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    #passwordRequirements li {
        margin-bottom: 5px;
    }

    .fas {
        margin-right: 5px;
    }
</style>

<div class="container my-5 py-5 ">
    <div class="col-lg-7 mx-auto">
        <div class="card ">
            <div class="card-body">
                <!-- Login Form -->
                <div id="loginForm">
                    <h1 class="h2">Welcome back!</h1>
                    <p class="lead">Sign in to your account to continue</p>
                    <?php
                    if ($logoutMessage) {
                        echo $logoutMessage;
                    }

                    if ($alert) {
                        echo $alert;
                    }
                    ?>
                    <form id="loginFormElement">
                        <div class="mb-3">
                            <label for="loginEmail" class="form-label">Email address</label>
                            <input type="email" class="custom-input form-control" id="loginEmail" name="email" placeholder="Enter email" />
                        </div>
                        <div class="mb-3 password-wrapper">
                            <label for="loginPassword" class="form-label">Password</label>
                            <input type="password" class="custom-input form-control" id="loginPassword" name="password" placeholder="Password" />
                            <span class="toggle-password3" id="toggleLoginPassword">
                                <i class="fas fa-eye" id="loginEyeIcon"></i>
                            </span>
                        </div>

                        <?php
                        if ($_SERVER["HTTP_HOST"] != "noble_updated.test") {
                        ?>
                            <div class="mb-3">
                                <div class="g-recaptcha" data-sitekey="6LcE3DIqAAAAAE4ZP5G6RQtCTDuD3YBIfjYwkzH2"></div>
                            </div>
                        <?php
                        }
                        ?>

                        <input type="hidden" name="login" value="1">
                        <button type="submit" class="btn btn-primary w-100" id="loginSubmit">Login</button>
                        <div class="switch-text mt-3">
                            I do not have an account? <a href="#" id="showRegister">Create a free account</a>
                        </div>
                    </form>
                </div>
                <!-- Registration Form -->
                <div id="registerForm" style="display: none;">

                    <form id="registerFormElement">
                        <div class="mb-3">
                            <label for="full_name" class="form-label">Full Name</label>
                            <input type="text" class="custom-input form-control" id="full_name" name="full_name"
                                placeholder="Enter full name" />
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email address</label>
                            <input type="email" class="custom-input form-control" id="email" name="email" placeholder="Enter email" />
                        </div>
                        <div class="mb-3 password-wrapper">
                            <label for="registerPassword" class="form-label">Password</label>
                            <input type="password" autocomplete="off" class="custom-input form-control" id="registerPassword" name="password"
                                placeholder="Password" />
                            <span class="toggle-password" id="toggleRegisterPassword">
                                <i class="fas fa-eye" id="registerEyeIcon"></i>
                            </span>
                            <div id="passwordStrengthWrapper" class="mt-2">
                                <div id="passwordStrengthBar" class="progress">
                                    <div id="passwordStrengthFill" class="progress-bar" role="progressbar"></div>
                                </div>
                                <div id="passwordStrengthText" class="mt-1"></div>
                                <ul id="passwordRequirements" class="mt-2">
                                    <li id="minLength">8 characters long.</li>
                                    <li id="uppercase">Uppercase.</li>
                                    <li id="lowercase">Lowercase.</li>
                                    <li id="number">Number.</li>
                                    <li id="specialChar">Special character.</li>
                                </ul>
                            </div>


                        </div>
                        <div class="mb-3 password-wrapper">
                            <label for="registerConfirmPassword" class="form-label">Confirm Password</label>
                            <input type="password" class="custom-input form-control" id="registerConfirmPassword" name="confirm_password"
                                placeholder="Confirm Password" />
                            <span class="toggle-password2" id="toggleConfirmPassword">
                                <i class="fas fa-eye" id="confirmEyeIcon"></i>
                            </span>
                        </div>

                        <?php
                        if ($_SERVER["HTTP_HOST"] != "noble_updated.test") {
                        ?>
                            <div class="mb-3">
                                <div class="g-recaptcha" data-sitekey="6LcE3DIqAAAAAE4ZP5G6RQtCTDuD3YBIfjYwkzH2"></div>
                            </div>
                        <?php } ?>

                        <input type="hidden" name="registration" value="1">
                        <button type="submit" class="btn btn-primary w-100 py-3" id="registerSubmit">Register</button>
                        <div class="switch-text mt-3">
                            I already have an account? <a href="#" id="showLogin">Login</a>
                        </div>
                    </form>
                    <script>
                        document.getElementById('registerPassword').addEventListener('input', function() {
                            const password = this.value;
                            const strength = getPasswordStrength(password);
                            const strengthFill = document.getElementById('passwordStrengthFill');
                            const strengthText = document.getElementById('passwordStrengthText');
                            const requirements = {
                                minLength: document.getElementById('minLength'),
                                uppercase: document.getElementById('uppercase'),
                                lowercase: document.getElementById('lowercase'),
                                number: document.getElementById('number'),
                                specialChar: document.getElementById('specialChar')
                            };

                            strengthFill.style.width = `${strength.percentage}%`;
                            strengthFill.className = 'progress-bar';
                            strengthFill.classList.add(getStrengthClass(strength.percentage));

                            strengthText.textContent = `Strength: ${strength.percentage}%`;

                            updateRequirements(password, requirements);
                        });

                        function getPasswordStrength(password) {
                            let score = 0;
                            const minLength = 8;
                            const hasUppercase = /[A-Z]/.test(password);
                            const hasLowercase = /[a-z]/.test(password);
                            const hasNumber = /[0-9]/.test(password);
                            const hasSpecialChar = /[!@#$%^&*()_+{}\[\]:;"'<>,.?/]/.test(password);

                            if (password.length >= minLength) score += 20;
                            if (hasUppercase) score += 20;
                            if (hasLowercase) score += 20;
                            if (hasNumber) score += 20;
                            if (hasSpecialChar) score += 20;

                            return {
                                percentage: score
                            };
                        }

                        function getStrengthClass(percentage) {
                            if (percentage >= 80) return 'bg-success';
                            if (percentage >= 50) return 'bg-warning';
                            return 'bg-danger';
                        }

                        function updateRequirements(password, requirements) {
                            const minLength = /^(?=.{8,})/.test(password);
                            const hasUppercase = /[A-Z]/.test(password);
                            const hasLowercase = /[a-z]/.test(password);
                            const hasNumber = /[0-9]/.test(password);
                            const hasSpecialChar = /[!@#$%^&*()_+{}\[\]:;"'<>,.?/]/.test(password);

                            toggleRequirement(requirements.minLength, minLength);
                            toggleRequirement(requirements.uppercase, hasUppercase);
                            toggleRequirement(requirements.lowercase, hasLowercase);
                            toggleRequirement(requirements.number, hasNumber);
                            toggleRequirement(requirements.specialChar, hasSpecialChar);
                        }

                        function toggleRequirement(element, condition) {
                            if (condition) {
                                element.classList.remove('text-danger');
                                element.classList.add('text-success');
                                element.innerHTML = '<i class="fas fa-check"></i> ' + element.textContent;
                            } else {
                                element.classList.remove('text-success');
                                element.classList.add('text-danger');
                                element.innerHTML = '<i class="fas fa-star"></i> ' + element.textContent;
                            }
                        }
                    </script>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Include these scripts in your HTML -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    // Toggle password visibility for login
    $('#toggleLoginPassword').on('click', function() {
        const passwordField = $('#loginPassword');
        const type = passwordField.attr('type') === 'password' ? 'text' : 'password';
        passwordField.attr('type', type);
        $('#loginEyeIcon').toggleClass('fa-eye fa-eye-slash');
    });

    // Toggle password visibility for registration
    $('#toggleRegisterPassword').on('click', function() {
        const passwordField = $('#registerPassword');
        const type = passwordField.attr('type') === 'password' ? 'text' : 'password';
        passwordField.attr('type', type);
        $('#registerEyeIcon').toggleClass('fa-eye fa-eye-slash');
    });

    $('#toggleConfirmPassword').on('click', function() {
        const confirmPasswordField = $('#registerConfirmPassword');
        const type = confirmPasswordField.attr('type') === 'password' ? 'text' : 'password';
        confirmPasswordField.attr('type', type);
        $('#confirmEyeIcon').toggleClass('fa-eye fa-eye-slash');
    });
    $(document).ready(function() {
        // Function to reset the reCAPTCHA widget
        function resetCaptcha() {
            if (grecaptcha && grecaptcha.getResponse) {
                console.log("Attempting to reset reCAPTCHA...");
                grecaptcha.reset();
                console.log("reCAPTCHA has been reset.");
            } else {
                console.error("grecaptcha object is not available or reset function is missing.");
            }
        }

        // Handle form submission with AJAX
        function handleFormSubmission(formId, actionUrl) {
            $(formId).on('submit', function(e) {
                e.preventDefault(); // Prevent the default form submission

                $.ajax({
                    url: actionUrl,
                    type: 'POST',
                    data: $(this).serialize(),
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Success!',
                                text: response.messages[0],
                                confirmButtonText: 'OK'
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    window.location.href = 'home';
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Oops...',
                                text: response.messages.join('\n'),
                            });
                            resetCaptcha(); // Reset CAPTCHA on error
                        }
                    },
                    error: function() {
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: 'Something went wrong with the AJAX request.',
                        });
                        resetCaptcha(); // Reset CAPTCHA on AJAX error
                    }
                });
            });
        }

        // Initialize form handlers
        handleFormSubmission('#registerFormElement', 'data/processors/authentications/process_registration.php');
        handleFormSubmission('#loginFormElement', 'data/processors/authentications/process_login.php');

        // Switch to Register Form
        $("#showRegister").click(function(e) {
            e.preventDefault();
            $("#loginForm").fadeOut('slow', function() {
                $("#registerForm").fadeIn('slow');
                $("#authModalLabel").html('Create a free account');
            });
        });

        // Switch to Login Form
        $("#showLogin").click(function(e) {
            e.preventDefault();
            $("#registerForm").fadeOut('slow', function() {
                $("#loginForm").fadeIn('slow');
                $("#authModalLabel").html('Login to access your account');
            });
        });
    });
</script>

<script>
    const passwordInput = document.getElementById('registerPassword');
    const strengthWrapper = document.getElementById('passwordStrengthWrapper');

    passwordInput.addEventListener('focus', () => {
        strengthWrapper.style.display = 'block';
    });

    passwordInput.addEventListener('blur', () => {
        strengthWrapper.style.display = 'none';
    });
</script>
<?php include_once "data/includes/footer.php"; ?>