<?php
include_once "data/includes/head-auth.php";

// Start the session
session_start();

// Check if the user is already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: home");
    exit;
}

// Display a message if the user has just logged out
$logoutMessage = '';
if (isset($_GET['loggedout']) && $_GET['loggedout'] === 'yes') {
    $logoutMessage = '<div class="alert alert-success p-3">You have been successfully logged out.</div>';
}

// Display status messages based on query parameters
$status = isset($_GET['status']) ? $_GET['status'] : '';

switch ($status) {
    case 'session_timed_out':
        $alert = '<div class="alert alert-warning p-3">Your session has timed out. Please log in again.</div>';
        break;
    case 'unauthorized_access':
        $alert = '<div class="alert alert-danger p-3">Unauthorized access. Please log in.</div>';
        break;
    case 'user_not_logged_in':
        $alert = '<div class="alert alert-danger p-3">You are not logged in. Please log in.</div>';
        break;
    case 'session_email_mismatch':
        $alert = '<div class="alert alert-danger p-3">Session email mismatch. Please log in again.</div>';
        break;


    case 'access_denied':
        $alert = '<div class="alert alert-danger p-3">Access denied. Admin privileges required.</div>';
        break;
    case 'reset_token_expired':
        $alert = '<div class="alert alert-danger p-3">Password reset token has expired. Please request a new one.</div>';
        break;

    case 'user_not_found':
        $alert = '<div class="alert alert-danger p-3">User not found. Please log in again.</div>';
        break;
    default:
        $alert = '';
        break;
}

?>

<body>
    <div class="wrapper">
        <main class="content">
            <div class="container-fluid p-0">
                <div class="auth-full-page d-flex">
                    <div class="auth-form p-3">
                        <div class="text-center">
                            <h1 class="h2">Welcome back!</h1>
                            <p class="lead">Sign in to your account to continue</p>
                            <?php
                            if ($logoutMessage) {
                                echo $logoutMessage;
                            }

                            if ($alert) {
                                echo $alert;
                            }
                            ?>

                        </div>

                        <div class="mb-3 card">
                            <div class="card-body">
                                <form id="loginForm">
                                    <div class="mb-3">
                                        <label for="email" class="form-label">Email</label>
                                        <input type="email" class="form-control" id="email_address" name="email_address" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="password" class="form-label">Password</label>
                                        <input type="password" class="form-control" id="password" name="password" required>
                                    </div>


                                    <button type="submit" class="btn btn-primary">Login</button>
                                    <div id="messageContainer" class="message-container">
                                        <i id="messageIcon" class="message-icon fas"></i>
                                        <p id="messageText"></p>
                                    </div>
                                </form>
                            </div>
                            <a href="forgot-password" class="d-block p-4">Forget password?</a>
                        </div>

                        <div class="">
                            Don't have an account? <a href="sign-up">Sign up</a>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <?php include_once "data/includes/footer.php"; ?>
       
        <script>
            $(document).ready(function() {
                $('#loginForm').on('submit', function(e) {
                    e.preventDefault();

                    var form = $(this);
                    var button = form.find('button[type="submit"]');
                    var originalButtonText = button.text();
                    var formData = form.serialize();

                    // Show loading text and disable the button
                    button.text('Please wait...').prop('disabled', true);

                    $.ajax({
                        url: 'data/processors/authentications/process_login.php',
                        type: 'POST',
                        data: formData,
                        dataType: 'json',
                        success: function(response) {
                            setTimeout(function() {
                                // Restore button state
                                button.text(originalButtonText).prop('disabled', false);

                                if (response.status === 'success') {
                                    showMessage('Login successful!', 'success');

                                    setTimeout(function() {
                                        window.location.href = 'home';
                                    }, 3000);
                                } else {
                                    showMessage(response.messages.join('<br>'), 'error');
                                }
                            }, 3000);
                        },
                        error: function(xhr, status, error) {
                            setTimeout(function() {
                                button.text(originalButtonText).prop('disabled', false);
                                showMessage('Login failed, please try again.', 'error');
                            }, 3000);
                        }
                    });
                });

                function showMessage(message, type) {
                    const container = $('#messageContainer');
                    const text = $('#messageText');
                    const icon = $('#messageIcon');

                    text.html(message);
                    container.removeClass('success error').addClass(type);
                    icon.attr('class', 'message-icon fas ' + (type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'));

                    container.show().css('opacity', 1);

                    setTimeout(() => {
                        container.animate({
                            opacity: 0
                        }, 2000, function() {
                            container.hide();
                        });
                    }, 3000);
                }
            });
        </script>

    </div>
</body>

</html>