<?php
include_once "data/includes/head-auth.php";
?>

<body>
    <div class="wrapper">
        <main class="content">
            <div class="container-fluid p-0">
                <div class="auth-full-page d-flex">
                    <div class="auth-form p-3">
                        <div class="text-center">
                            <h1 class="h2">Forget Password</h1>
                            <p class="lead">Enter your email to send a password reset link to your email for a secured password reset</p>


                        </div>

                        <div class="mb-3 card">
                            <div class="card-body">
                                <form id="forgot_password_form">
                                    <div class="mb-3">
                                        <label for="email" class="form-label">Email</label>
                                        <input type="email" class="form-control" id="email" name="email">
                                    </div>

                                    <button type="submit" class="btn btn-primary">Login</button>
                                    <div id="messageContainer" class="message-container">
                                        <i id="messageIcon" class="message-icon fas"></i>
                                        <p id="messageText"></p>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="">
                            <a href="sign-in">login</a>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <?php include_once "data/includes/footer.php"; ?>
        <script>
            $(document).ready(function() {
                $('#forgot_password_form').on('submit', function(e) {
                    e.preventDefault();

                    var form = $(this);
                    var button = form.find('button[type="submit"]');
                    var originalButtonText = button.text();
                    var formData = form.serialize();

                    // Show loading text and disable the button
                    button.text('Please wait...').prop('disabled', true);

                    $.ajax({
                        url: 'data/processors/authentications/process_forgot_password.php',
                        type: 'POST',
                        data: formData,
                        dataType: 'json',
                        success: function(response) {
                            setTimeout(function() {
                                // Restore button state
                                button.text(originalButtonText).prop('disabled', false);

                                if (response.status === 'success') {
                                    showMessage('Reset link has been sent to your email address, this might take few minute to drop, check both spam and inbox folder', 'success');

                                    setTimeout(function() {
                                        window.location.href = 'home';
                                    }, 3000);
                                } else {
                                    showMessage(response.messages.join('<br>'), 'error');
                                }
                            }, 3000);
                        },
                        error: function(xhr, status, error) {
                            setTimeout(function() {
                                button.text(originalButtonText).prop('disabled', false);
                                showMessage('Login failed, please try again.', 'error');
                            }, 3000);
                        }
                    });
                });

                function showMessage(message, type) {
                    const container = $('#messageContainer');
                    const text = $('#messageText');
                    const icon = $('#messageIcon');

                    text.html(message);
                    container.removeClass('success error').addClass(type);
                    icon.attr('class', 'message-icon fas ' + (type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'));

                    container.show().css('opacity', 1);

                    setTimeout(() => {
                        container.animate({
                            opacity: 0
                        }, 2000, function() {
                            container.hide();
                        });
                    }, 3000);
                }
            });
        </script>

    </div>



</body>

</html>