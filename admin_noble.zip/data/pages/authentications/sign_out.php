<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: sign-in");
    exit;
}

if (isset($_POST['confirmLogout'])) {
    require 'data/processors/authentications/process_sign-out.php';
    exit;
}
?>

<?php include_once "data/includes/head-auth.php"; ?>
<style>
    .confirmation-container {
        margin: auto;
        margin-top: 50px;
        max-width: 500px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .confirmation-header {
        background-color: #2c7a7b;
        color: white;
        text-align: center;
        padding: 20px;
        border-top-left-radius: 8px;
        border-top-right-radius: 8px;
    }

    .confirmation-header .confirmation-title {
        font-weight: bold;
        font-size: 1.5rem;
    }

    .confirmation-body {
        text-align: center;
        padding: 30px 20px;
    }

    .confirmation-body i {
        font-size: 3rem;
        color: #2c7a7b;
        margin-bottom: 20px;
    }

    .confirmation-body p {
        font-size: 1.2rem;
        margin-bottom: 30px;
    }

    .confirmation-footer {
        text-align: center;
        padding: 20px;
        border-bottom-left-radius: 8px;
        border-bottom-right-radius: 8px;
    }

    .btn-secondary {
        background-color: #6c757d;
        border-color: #6c757d;
    }

    .btn-primary {
        background-color: #2c7a7b;
        border-color: #2c7a7b;
    }

    .btn-secondary:hover,
    .btn-primary:hover {
        opacity: 0.9;
    }
</style>

<body>

    <div class="confirmation-container">
        <div class="confirmation-header">
            <h5 class="confirmation-title">Confirm Logout</h5>
        </div>
        <div class="confirmation-body">
            <i class="fas fa-sign-out-alt"></i> <!-- FontAwesome Logout Icon -->
            <p>Are you sure you really want to logout?</p>
        </div>
        <div class="confirmation-footer">
            <form method="post">
                <button type="button" class="btn btn-secondary" onclick="window.location.href='home'">Cancel</button>
                <button type="submit" name="confirmLogout" class="btn btn-primary">Yes, Logout</button>
            </form>
        </div>
    </div>

    <?php include_once "data/includes/footer.php"; ?>
</body>

</html>