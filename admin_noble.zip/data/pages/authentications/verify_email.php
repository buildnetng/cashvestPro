<?php
session_start();
include_once "data/includes/head-auth.php";

$status = isset($_GET['status']) ? $_GET['status'] : '';
$user_email = isset($_SESSION['user_email']) ? $_SESSION['user_email'] : null;

switch ($status) {
    case 'email_verification_required':
        $alert = '<div class="alert-info p-3 rounded-2">
                <div class="text-warning col-12 d-block">
                    Email verification is required.
                </div>
                <div class="col-12 d-block">
                    UPDATE: We sent a message with the verification code to ' . $user_email . '. It may take a few minutes for the code to arrive.
                </div>
              </div>';
        break;

        break;
    default:
        $alert = '';
        break;
}

?>


<body>
    <div class="wrapper">
        <main class="content">
            <div class="container-fluid p-0">
                <div class="auth-full-page d-flex">
                    <div class="auth-form p-3">
                        <div class="text-center">
                            <h1 class="h2">Email Verification</h1>
                            <?= $alert ?>

                        </div>
                        <div class="mb-3">


                            <form id="verifyEmail">
                                <div class="mb-3">
                                    <label for="verification_code" class="form-label">Verification Code</label>
                                    <input type="text" class="form-control" id="verification_code" name="verification_code" maxlength="6">
                                </div>
                                <input type="hidden" name="email" value="<?= htmlspecialchars($user_email) ?>">

                                <button type="submit" class="btn btn-primary">Verify Email</button>
                                <button type="button" id="resendEmailButton" class="btn btn-secondary">Resend Email</button>

                                <div id="messageContainer" class="message-container">
                                    <i id="messageIcon" class="message-icon fas"></i>
                                    <p id="messageText"></p>
                                </div>
                            </form>
                        </div>


                        <div>
                            <a href="sign-out" class="text-danger">logout</a>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <script>
            $(document).ready(function() {
                $('#verification_code').on('input', function() {
                    this.value = this.value.replace(/[^0-9]/g, '').substring(0, 6);
                });

                $('#verifyEmail').on('submit', function(e) {
                    e.preventDefault();

                    var form = $(this);
                    var button = form.find('button[type="submit"]');
                    var originalButtonText = button.text();
                    var formData = form.serialize();

                    // Show loading text and disable the button
                    button.text('Please wait...').prop('disabled', true);

                    $.ajax({
                        url: 'data/processors/authentications/process_verify_email.php',
                        type: 'POST',
                        data: formData,
                        dataType: 'json',
                        success: function(response) {
                            // Keep "Please wait..." visible for 5 seconds before showing the response
                            setTimeout(function() {
                                // Restore button state
                                button.text(originalButtonText).prop('disabled', false);

                                if (response.status === 'success') {
                                    // Display success message
                                    showMessage('Email verified successfully!', 'success');

                                    // Redirect after a 3-second delay
                                    setTimeout(function() {
                                        window.location.href = 'home';
                                    }, 3000);
                                } else {
                                    // Display other error messages
                                    if (Array.isArray(response.messages)) {
                                        // Display the error messages
                                        showMessage(response.messages.join('<br>'), 'error');
                                    } else {
                                        // Display a single message
                                        showMessage(response.messages || 'An error occurred. Please try again.', 'error');
                                    }
                                }
                            }, 5000); // 5 seconds delay for "Please wait..." to show
                        },
                        error: function(xhr, status, error) {
                            // Keep "Please wait..." visible for 5 seconds before handling the error
                            setTimeout(function() {
                                // Restore button state
                                button.text(originalButtonText).prop('disabled', false);

                                // Display generic error message
                                showMessage('Login failed, please try again.', 'error');
                            }, 5000); // 5 seconds delay for "Please wait..." to show
                        }
                    });
                });

                // Handle Resend Email Button
                $('#resendEmailButton').on('click', function() {
                    var button = $(this);
                    var originalButtonText = button.text();
                    var email = $('input[name="email"]').val();

                    // Show loading text and disable the button
                    button.text('Resending...').prop('disabled', true);

                    $.ajax({
                        url: 'data/processors/authentications/resend_verification_email.php',
                        type: 'POST',
                        data: {
                            email: email
                        },
                        dataType: 'json',
                        success: function(response) {
                            setTimeout(function() {
                                // Restore button state
                                button.text(originalButtonText).prop('disabled', false);

                                if (response.status === 'success') {
                                    showMessage('Verification email resent successfully!', 'success');
                                } else {
                                    showMessage(response.message || 'Failed to resend verification email.', 'error');
                                }
                            }, 2000); // 2 seconds delay to show the resend process
                        },
                        error: function(xhr, status, error) {
                            setTimeout(function() {
                                // Restore button state
                                button.text(originalButtonText).prop('disabled', false);

                                // Display generic error message
                                showMessage('Failed to resend email, please try again.', 'error');
                            }, 2000); // 2 seconds delay to show the resend process
                        }
                    });
                });

                function showMessage(message, type) {
                    const container = $('#messageContainer');
                    const text = $('#messageText');
                    const icon = $('#messageIcon');

                    text.html(message);
                    container.removeClass('success error').addClass(type);
                    icon.attr('class', 'message-icon fas ' + (type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'));

                    container.show().css('opacity', 1);

                    setTimeout(() => {
                        container.animate({
                            opacity: 0
                        }, 2000, function() {
                            container.hide();
                        });
                    }, 3000);
                }
            });
        </script>

        <?php include_once "data/includes/footer.php"; ?>