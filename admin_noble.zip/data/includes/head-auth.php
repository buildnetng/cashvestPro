<!DOCTYPE html>
<html lang="en" data-bs-theme="dark" data-layout="fluid" data-sidebar-theme="dark" data-sidebar-position="left"
	data-sidebar-behavior="sticky">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">

	<title>Noble Teachers</title>

	<link rel="canonical" href="dashboard-default.html" />
	<link rel="shortcut icon" href="img/favicon.ico">

	<link rel="preconnect" href="https://fonts.googleapis.com/">
	<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500&amp;display=swap" rel="stylesheet">

	<link href="assets/css/app.css" rel="stylesheet">
	<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<style>
		.message-container {
			position: fixed;
			top: 20px;
			right: 20px;
			width: 320px;
			padding: 15px;
			border-radius: 5px;
			z-index: 9999;
			box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
			font-family: Arial, sans-serif;
			font-size: 14px;
			display: flex;
			align-items: center;
			opacity: 0;
			transition: opacity 0.5s ease-in-out;
		}

		.message-container.success {
			background-color: #2c7a7b;
			color: #ffffff;
		}

		.message-container.error {
			background-color: #e53e3e;
			color: #ffffff;
		}

		.message-icon {
			margin-right: 10px;
			font-size: 18px;
			color: #ffffff;
		}
	</style>



</head>