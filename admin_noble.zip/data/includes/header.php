<nav id="sidebar" class="sidebar">
	<div class="sidebar-content js-simplebar">

		<ul class="sidebar-nav">

			<li class="sidebar-item mt-5 active">
				<a href="home" class="sidebar-link">
					<i class="fa fa-tachometer-alt align-middle"></i>
					<span class="align-middle">Dashboard</span>
				</a>
			</li>

			<li class="sidebar-item">
				<a data-bs-target="#applications" data-bs-toggle="collapse" class="sidebar-link collapsed">
					<i class="fa fa-shopping-bag align-middle"></i>
					<span class="align-middle">Emergencies</span>
				</a>
				<ul id="applications" class="sidebar-dropdown list-unstyled collapse " data-bs-parent="#sidebar">
					<li class="sidebar-item"><a class='sidebar-link' href='applications'>Applications</a></li>
					<li class="sidebar-item"><a class='sidebar-link' href='enquiries'>Enquiries</a></li>
				</ul>
			</li>

			<li class="sidebar-item">
				<a class='sidebar-link' href='noble_teachers'>
					<i class="fa fa-users align-middle"></i>
					<span class="align-middle">Noble Teachers</span>
				</a>
			</li>

			<li class="sidebar-item">
				<a data-bs-target="#jobs_view" data-bs-toggle="collapse" class="sidebar-link collapsed">
					<i class="fa fa-briefcase align-middle"></i>
					<span class="align-middle">Job Listing</span>
				</a>
				<ul id="jobs_view" class="sidebar-dropdown list-unstyled collapse " data-bs-parent="#sidebar">
					<li class="sidebar-item"><a class='sidebar-link' href='job-add'>Add</a></li>
					<li class="sidebar-item"><a class='sidebar-link' href='job-views'>View</a></li>
					<li class="sidebar-item"><a class='sidebar-link' href='job-comments'>Comments</a></li>
				</ul>
			</li>

			<li class="sidebar-item">
				<a data-bs-target="#blog_view" data-bs-toggle="collapse" class="sidebar-link collapsed">
					<i class="fa fa-pencil-alt align-middle"></i>
					<span class="align-middle">Blog</span>
				</a>
				<ul id="blog_view" class="sidebar-dropdown list-unstyled collapse " data-bs-parent="#sidebar">
					<li class="sidebar-item"><a class='sidebar-link' href='insert-blog-post'>Add</a></li>
					<li class="sidebar-item"><a class='sidebar-link' href='view-blog-post'>View</a></li>
				</ul>
			</li>

			<li class="sidebar-item">
				<a class='sidebar-link' href='mailer'>
					<i class="fa fa-envelope align-middle"></i>
					<span class="align-middle">Mailer</span>
				</a>
			</li>

			<li class="sidebar-item">
				<a class='sidebar-link' href='newsletters'>
					<i class="fa fa-paperclip align-middle"></i>
					<span class="align-middle">Newsletters</span>
				</a>
			</li>

			<li class="sidebar-item">
				<a class='sidebar-link' href='reviews'>
					<i class="fa fa-globe align-middle"></i>
					<span class="align-middle">Reviews</span>
				</a>
			</li>

			<li class="sidebar-item">
				<a class='sidebar-link' href='profile'>
					<i class="fa fa-user align-middle"></i>
					<span class="align-middle">Profile</span>
				</a>
			</li>

			<li class="sidebar-item">
				<a data-bs-target="#settings" data-bs-toggle="collapse" class="sidebar-link collapsed">
					<i class="fa fa-cogs align-middle"></i>
					<span class="align-middle">Settings</span>
				</a>
				<ul id="settings" class="sidebar-dropdown list-unstyled collapse " data-bs-parent="#sidebar">
					<li class="sidebar-item"><a class='sidebar-link' href='settings'>Advanced Settings</a></li>
				</ul>
			</li>

		</ul>

	</div>
</nav>

<div class="main">
	<nav class="navbar navbar-expand navbar-bg">
		<a class="sidebar-toggle">
			<i class="hamburger align-self-center"></i>
		</a>


		<div class="navbar-collapse collapse">
			<ul class="navbar-nav navbar-align">


				<li class="nav-item dropdown">
					<a class="nav-icon dropdown-toggle d-inline-block d-sm-none" href="#"
						data-bs-toggle="dropdown">
						<i class="align-middle" data-lucide="settings"></i>
					</a>

					<a class="nav-link dropdown-toggle d-none d-sm-inline-block" href="#"
						data-bs-toggle="dropdown">
						<img src="assets/img/avatars/avatar.jpg" class="img-fluid rounded-circle me-1 mt-n2 mb-n2"
							alt="Chris Wood" width="40" height="40" /> <span><?= $user["full_name"]; ?></span>
					</a>
					<div class="dropdown-menu dropdown-menu-end">
						<a class='dropdown-item' href='profile'><i class="align-middle me-1"
								data-lucide="user"></i> Profile</a>

						<div class="dropdown-divider"></div>
						<a class='dropdown-item' href='settings'>Settings</a>
						<a class="dropdown-item" href="sign-out">Sign out</a>
					</div>
				</li>
			</ul>
		</div>
	</nav>