<?php

// Log directory and file setup
$error_log_dir = 'logs';
$error_log_file = $error_log_dir . '/error.log';

// Ensure the log directory exists
if (!is_dir($error_log_dir)) {
    mkdir($error_log_dir, 0755, true);
}

// Display errors on the live server
ini_set('display_errors', '1'); // Set to '0' on production for security
ini_set('display_startup_errors', '1');
error_reporting(E_ALL); // Show all errors for debugging

// Set custom error handler to log detailed errors
function custom_error_handler($errno, $errstr, $errfile, $errline)
{
    global $error_log_file;

    // Format the error message with date, time, and file info
    $date_time = date('Y-m-d H:i:s');
    $error_message = "[{$date_time}] Error: {$errstr} in {$errfile} on line {$errline}\n";

    // Log the error message to the log file
    error_log($error_message, 3, $error_log_file);

    // Display the error for debugging
    echo nl2br($error_message);
}

// Set the custom error handler
set_error_handler('custom_error_handler');

// Ensure PHP error logging is enabled
ini_set('log_errors', 'On');
ini_set('error_log', $error_log_file);

// File download handling
if (isset($_GET['file'])) {
    $file_path = $_GET['file'];
    $base_dir = realpath('uploads'); // Base directory for downloads

    // Ensure the file path is safe and within the allowed directory
    $real_path = realpath($file_path);

    if ($real_path && strpos($real_path, $base_dir) === 0 && file_exists($real_path)) {
        // Set headers to force download
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($real_path) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($real_path));

        // Read the file and output its contents
        readfile($real_path);
        exit;
    } else {
        $date_time = date('Y-m-d H:i:s');
        $error_message = "[{$date_time}] Error 404: File not found or unauthorized access attempt for '{$file_path}'\n";
        error_log($error_message, 3, $error_log_file);

        http_response_code(404);
        include '404.php';
        exit;
    }
}

// Existing routing logic
$route = isset($_GET['route']) ? str_replace('-', '_', $_GET['route']) : 'home';

$routes = [
    '' => 'data/pages/admin/home.php',
    'home' => 'data/pages/admin/home.php',
    'index' => 'data/pages/admin/home.php',
    'applications' => 'data/pages/admin/applications.php',
    'enquiries' => 'data/pages/admin/enquiries.php',
    'noble_teachers' => 'data/pages/admin/noble_teachers.php',
    'profile' => 'data/pages/admin/profile.php',
    'job_add' => 'data/pages/admin/job_add.php',
    'insert_blog_post' => 'data/pages/admin/insert_blog_post.php',
    'view_blog_post' => 'data/pages/admin/view_blog_post.php',
    'job_views' => 'data/pages/admin/job_views.php',
    'job_comments' => 'data/pages/admin/job_comments.php',
    'mailer' => 'data/pages/admin/mailer.php',
    'reviews' => 'data/pages/admin/reviews.php',
    'newsletters' => 'data/pages/admin/newsletters.php',
    'settings' => 'data/pages/admin/settings.php',
    'feedback' => 'data/pages/admin/feedback.php',
    'account' => 'data/pages/admin/account.php',
    'my_jobs' => 'data/pages/admin/my_jobs.php',
    'sign_in' => 'data/pages/authentications/sign_in.php',
    'auth' => 'data/pages/authentications/auth.php',
    'verify_email' => 'data/pages/authentications/verify_email.php',
    'sign_out' => 'data/pages/authentications/sign_out.php',
    'forgot_password' => 'data/pages/authentications/forgot_password.php',
];

if (array_key_exists($route, $routes)) {
    require $routes[$route];
} else {
    $date_time = date('Y-m-d H:i:s');
    $error_message = "[{$date_time}] Error 404: Route not found for '{$route}'\n";
    error_log($error_message, 3, $error_log_file);

    http_response_code(404);
    include '404.php';
}
